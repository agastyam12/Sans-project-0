/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class WhiteBoneAttack8 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "bone-hole-top",
        "./WhiteBoneAttack8/costumes/bone-hole-top.svg",
        { x: 20.064760000000007, y: -224.9153 }
      ),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Attack-2" },
        this.whenIReceiveAttack2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenIReceiveAttack2() {
    this.moveBehind();
    this.visible = true;
    this.costume = "bone-hole-top";
    this.goto(120, 30);
    yield* this.wait(0.875);
    for (let i = 0; i < 2; i++) {
      yield* this.glide(1.75, -120, this.y);
      yield* this.glide(1.75, 120, this.y);
      yield;
    }
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
