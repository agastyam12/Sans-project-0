/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class StartButton extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./StartButton/costumes/costume1.png", {
        x: 215,
        y: 222,
      }),
    ];

    this.sounds = [new Sound("pop", "./StartButton/sounds/pop.wav")];

    this.triggers = [new Trigger(Trigger.CLICKED, this.whenthisspriteclicked)];
  }

  *whenthisspriteclicked() {
    this.costume = "costume1";
    this.visible = true;
    this.stage.costume = "Start-game-normal-mode-set";
    this.broadcast("Game-start-normal-mode");
    this.visible = false;
  }
}
