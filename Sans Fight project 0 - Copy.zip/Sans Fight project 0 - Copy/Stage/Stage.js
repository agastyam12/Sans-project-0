/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "Start-game-normal-mode-set",
        "./Stage/costumes/Start-game-normal-mode-set.svg",
        { x: 333.24093, y: 208.993805 }
      ),
      new Costume(
        "Game-start-normal-mode",
        "./Stage/costumes/Game-start-normal-mode.svg",
        { x: 333.24092753633937, y: 208.9938038089067 }
      ),
      new Costume("Blackout", "./Stage/costumes/Blackout.svg", {
        x: 333.24093,
        y: 208.993805,
      }),
      new Costume("Game complete", "./Stage/costumes/Game complete.svg", {
        x: 333.24093,
        y: 208.99379499999998,
      }),
    ];

    this.sounds = [new Sound("flash", "./Stage/sounds/flash.mp3")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenbackdropswitchesto3
      ),
    ];

    this.vars.gameSetNormalMode = "game-set-normal-mode-true";
    this.vars.blackout = 0;
    this.vars.animationNumber = 2;
    this.vars.borderX = 101;
    this.vars.borderY = 15;
    this.vars.borderNx = -102;
    this.vars.borderNy = -87;
    this.vars.soulType = "blue";
    this.vars.yVel = 0;
    this.vars.health = -8240;
    this.vars.movementAllowCheck = "true";
    this.vars.optionNumber = 100;
    this.vars.fightBarMovement = 0;
    this.vars.animationType = 0;
    this.vars.dodges = 1;
    this.vars.attackNo = 1;
    this.vars.fightSelect = "false";
    this.vars.music = "play";
    this.vars.playerTurn = 0;
    this.vars.actSelect = 0;
    this.vars.slashes = 1;
    this.vars.itemSelect = -231;
    this.vars.itemStart = "true";
  }

  *whenbackdropswitchesto() {
    this.stopAllSounds();
    this.vars.animationNumber = 0;
    this.vars.animationType = 0;
    this.vars.blackout = 0;
    this.vars.borderNx = 0;
    this.vars.borderX = 0;
    this.vars.borderNy = 0;
    this.vars.borderY = 0;
    this.vars.gameSetNormalMode = 0;
    this.vars.fightBarMovement = 0;
    this.vars.health = 0;
    this.vars.movementAllowCheck = 0;
    this.vars.optionNumber = 0;
    this.vars.music = 0;
    this.vars.yVel = 0;
    this.vars.soulType = 0;
    this.vars.playerTurn = 0;
    yield* this.wait(1);
    this.vars.gameSetNormalMode = "false";
    if (this.toString(this.vars.gameSetNormalMode) === "false") {
      yield* this.wait(0.5);
      this.costume = "Game-start-normal-mode";
      this.vars.gameSetNormalMode = "true";
    }
  }

  *whenbackdropswitchesto2() {
    if (this.toString(this.vars.gameSetNormalMode) === "true") {
      this.broadcast("Game-start-normal-mode");
      this.vars.gameSetNormalMode = "game-set-normal-mode-true";
    }
  }

  *whenbackdropswitchesto3() {
    yield* this.startSound("flash");
    yield* this.wait(0.2);
    yield* this.startSound("flash");
    this.broadcast("Blackout-done-normal-mode");
    this.broadcast("Attack-1-normal-mode");
    this.costume = "Game-start-normal-mode";
  }
}
