/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class ItemBoard extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("page 1", "./ItemBoard/costumes/page 1.png", {
        x: 289,
        y: 76,
      }),
      new Costume("page 2", "./ItemBoard/costumes/page 2.png", {
        x: 289,
        y: 76,
      }),
    ];

    this.sounds = [new Sound("pop", "./ItemBoard/sounds/pop.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Select-item" },
        this.whenIReceiveSelectItem
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game-start-normal-mode" },
        this.whenIReceiveGameStartNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenIReceiveSelectItem() {
    this.visible = true;
    this.costume = "page 1";
    while (!(this.toString(this.stage.vars.itemStart) === "false")) {
      if (this.compare(this.stage.vars.itemSelect, 4) > 0) {
        this.costume = "page 2";
      }
      if (this.compare(this.stage.vars.itemSelect, 4) < 0) {
        this.costume = "page 1";
      }
      yield;
    }
  }

  *whenIReceiveGameStartNormalMode() {
    this.visible = false;
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
