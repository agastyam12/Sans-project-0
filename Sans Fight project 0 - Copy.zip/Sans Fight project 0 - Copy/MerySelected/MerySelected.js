/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class MerySelected extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "undertale_text_box (7)",
        "./MerySelected/costumes/undertale_text_box (7).png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)2",
        "./MerySelected/costumes/undertale_text_box (7)2.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)3",
        "./MerySelected/costumes/undertale_text_box (7)3.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)4",
        "./MerySelected/costumes/undertale_text_box (7)4.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)5",
        "./MerySelected/costumes/undertale_text_box (7)5.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)6",
        "./MerySelected/costumes/undertale_text_box (7)6.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)7",
        "./MerySelected/costumes/undertale_text_box (7)7.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)8",
        "./MerySelected/costumes/undertale_text_box (7)8.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)9",
        "./MerySelected/costumes/undertale_text_box (7)9.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)10",
        "./MerySelected/costumes/undertale_text_box (7)10.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)11",
        "./MerySelected/costumes/undertale_text_box (7)11.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)12",
        "./MerySelected/costumes/undertale_text_box (7)12.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)13",
        "./MerySelected/costumes/undertale_text_box (7)13.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)14",
        "./MerySelected/costumes/undertale_text_box (7)14.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)15",
        "./MerySelected/costumes/undertale_text_box (7)15.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)16",
        "./MerySelected/costumes/undertale_text_box (7)16.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)17",
        "./MerySelected/costumes/undertale_text_box (7)17.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)18",
        "./MerySelected/costumes/undertale_text_box (7)18.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)20",
        "./MerySelected/costumes/undertale_text_box (7)20.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)21",
        "./MerySelected/costumes/undertale_text_box (7)21.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)22",
        "./MerySelected/costumes/undertale_text_box (7)22.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)23",
        "./MerySelected/costumes/undertale_text_box (7)23.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)24",
        "./MerySelected/costumes/undertale_text_box (7)24.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)25",
        "./MerySelected/costumes/undertale_text_box (7)25.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)26",
        "./MerySelected/costumes/undertale_text_box (7)26.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)27",
        "./MerySelected/costumes/undertale_text_box (7)27.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)28",
        "./MerySelected/costumes/undertale_text_box (7)28.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)30",
        "./MerySelected/costumes/undertale_text_box (7)30.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)31",
        "./MerySelected/costumes/undertale_text_box (7)31.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)19",
        "./MerySelected/costumes/undertale_text_box (7)19.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)32",
        "./MerySelected/costumes/undertale_text_box (7)32.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)33",
        "./MerySelected/costumes/undertale_text_box (7)33.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)35",
        "./MerySelected/costumes/undertale_text_box (7)35.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)34",
        "./MerySelected/costumes/undertale_text_box (7)34.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)36",
        "./MerySelected/costumes/undertale_text_box (7)36.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)37",
        "./MerySelected/costumes/undertale_text_box (7)37.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)38",
        "./MerySelected/costumes/undertale_text_box (7)38.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)40",
        "./MerySelected/costumes/undertale_text_box (7)40.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)29",
        "./MerySelected/costumes/undertale_text_box (7)29.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)41",
        "./MerySelected/costumes/undertale_text_box (7)41.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)42",
        "./MerySelected/costumes/undertale_text_box (7)42.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)44",
        "./MerySelected/costumes/undertale_text_box (7)44.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)45",
        "./MerySelected/costumes/undertale_text_box (7)45.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)46",
        "./MerySelected/costumes/undertale_text_box (7)46.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)47",
        "./MerySelected/costumes/undertale_text_box (7)47.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)48",
        "./MerySelected/costumes/undertale_text_box (7)48.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)49",
        "./MerySelected/costumes/undertale_text_box (7)49.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)50",
        "./MerySelected/costumes/undertale_text_box (7)50.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)51",
        "./MerySelected/costumes/undertale_text_box (7)51.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)52",
        "./MerySelected/costumes/undertale_text_box (7)52.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)53",
        "./MerySelected/costumes/undertale_text_box (7)53.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)54",
        "./MerySelected/costumes/undertale_text_box (7)54.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)55",
        "./MerySelected/costumes/undertale_text_box (7)55.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)56",
        "./MerySelected/costumes/undertale_text_box (7)56.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)57",
        "./MerySelected/costumes/undertale_text_box (7)57.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)58",
        "./MerySelected/costumes/undertale_text_box (7)58.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)59",
        "./MerySelected/costumes/undertale_text_box (7)59.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)60",
        "./MerySelected/costumes/undertale_text_box (7)60.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)61",
        "./MerySelected/costumes/undertale_text_box (7)61.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)39",
        "./MerySelected/costumes/undertale_text_box (7)39.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)63",
        "./MerySelected/costumes/undertale_text_box (7)63.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)64",
        "./MerySelected/costumes/undertale_text_box (7)64.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)65",
        "./MerySelected/costumes/undertale_text_box (7)65.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)66",
        "./MerySelected/costumes/undertale_text_box (7)66.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)67",
        "./MerySelected/costumes/undertale_text_box (7)67.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)68",
        "./MerySelected/costumes/undertale_text_box (7)68.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)69",
        "./MerySelected/costumes/undertale_text_box (7)69.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)70",
        "./MerySelected/costumes/undertale_text_box (7)70.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)71",
        "./MerySelected/costumes/undertale_text_box (7)71.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)72",
        "./MerySelected/costumes/undertale_text_box (7)72.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)73",
        "./MerySelected/costumes/undertale_text_box (7)73.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)74",
        "./MerySelected/costumes/undertale_text_box (7)74.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)75",
        "./MerySelected/costumes/undertale_text_box (7)75.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)76",
        "./MerySelected/costumes/undertale_text_box (7)76.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)77",
        "./MerySelected/costumes/undertale_text_box (7)77.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)78",
        "./MerySelected/costumes/undertale_text_box (7)78.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)79",
        "./MerySelected/costumes/undertale_text_box (7)79.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)80",
        "./MerySelected/costumes/undertale_text_box (7)80.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)81",
        "./MerySelected/costumes/undertale_text_box (7)81.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)82",
        "./MerySelected/costumes/undertale_text_box (7)82.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)83",
        "./MerySelected/costumes/undertale_text_box (7)83.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)84",
        "./MerySelected/costumes/undertale_text_box (7)84.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)43",
        "./MerySelected/costumes/undertale_text_box (7)43.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)86",
        "./MerySelected/costumes/undertale_text_box (7)86.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)87",
        "./MerySelected/costumes/undertale_text_box (7)87.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)88",
        "./MerySelected/costumes/undertale_text_box (7)88.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)89",
        "./MerySelected/costumes/undertale_text_box (7)89.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)90",
        "./MerySelected/costumes/undertale_text_box (7)90.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)91",
        "./MerySelected/costumes/undertale_text_box (7)91.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)92",
        "./MerySelected/costumes/undertale_text_box (7)92.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)93",
        "./MerySelected/costumes/undertale_text_box (7)93.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)94",
        "./MerySelected/costumes/undertale_text_box (7)94.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)95",
        "./MerySelected/costumes/undertale_text_box (7)95.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)96",
        "./MerySelected/costumes/undertale_text_box (7)96.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)97",
        "./MerySelected/costumes/undertale_text_box (7)97.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)98",
        "./MerySelected/costumes/undertale_text_box (7)98.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)99",
        "./MerySelected/costumes/undertale_text_box (7)99.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)100",
        "./MerySelected/costumes/undertale_text_box (7)100.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)101",
        "./MerySelected/costumes/undertale_text_box (7)101.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)102",
        "./MerySelected/costumes/undertale_text_box (7)102.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)103",
        "./MerySelected/costumes/undertale_text_box (7)103.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)104",
        "./MerySelected/costumes/undertale_text_box (7)104.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (7)105",
        "./MerySelected/costumes/undertale_text_box (7)105.png",
        { x: 291, y: 78 }
      ),
    ];

    this.sounds = [new Sound("pop", "./MerySelected/sounds/pop.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Mercy-selected" },
        this.whenIReceiveMercySelected
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenIReceiveMercySelected() {
    this.visible = true;
    yield* this.dialougeRun();
    yield* this.wait(3);
    this.visible = false;
    this.broadcast("sans-turn");
  }

  *dialougeRun() {
    this.costume = "undertale_text_box (7)";
    for (let i = 0; i < 101; i++) {
      this.costumeNumber++;
      yield;
    }
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
