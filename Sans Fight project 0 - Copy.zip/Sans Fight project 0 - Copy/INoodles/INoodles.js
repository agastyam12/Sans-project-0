/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class INoodles extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "undertale_text_box (8)",
        "./INoodles/costumes/undertale_text_box (8).png",
        { x: 34, y: 76 }
      ),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Select-item" },
        this.whenIReceiveSelectItem
      ),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game-start-normal-mode" },
        this.whenIReceiveGameStartNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];

    this.vars.iNoodlesUsable = "true";
  }

  *whenIReceiveSelectItem() {
    if (this.toString(this.vars.iNoodlesUsable) === "true") {
      this.moveAhead();
      this.visible = true;
      this.goto(0, -37);
    }
  }

  *whenKeySpacePressed() {
    if (this.toString(this.vars.iNoodlesUsable) === "true") {
      if (this.toNumber(this.stage.vars.itemSelect) === 2) {
        this.vars.iNoodlesUsable = "false";
        this.visible = false;
        this.broadcast("Steak eaten");
      }
    }
  }

  *whenbackdropswitchesto() {
    this.vars.iNoodlesUsable = "true";
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenIReceiveGameStartNormalMode() {
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
