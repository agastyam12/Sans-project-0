import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Player extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "player-heart-red",
        "./Player/costumes/player-heart-red.svg",
        { x: 44.43376785714287, y: 44.43376785714287 }
      ),
      new Costume(
        "player-heart-blue",
        "./Player/costumes/player-heart-blue.svg",
        { x: 44.920124999999985, y: 44.920124999999985 }
      ),
    ];

    this.sounds = [
      new Sound("battlestart_1", "./Player/sounds/battlestart_1.mp3"),
      new Sound("battlestart_2", "./Player/sounds/battlestart_2.mp3"),
      new Sound("soul-switch", "./Player/sounds/soul-switch.mp3"),
      new Sound("dmg_taken", "./Player/sounds/dmg_taken.mp3"),
    ];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game-start-normal-mode" },
        this.whenIReceiveGameStartNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-done-normal-mode" },
        this.whenIReceiveBlackoutDoneNormalMode
      ),
      new Trigger(Trigger.KEY_PRESSED, { key: "a" }, this.whenKeyAPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "w" }, this.whenKeyWPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "s" }, this.whenKeySPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "d" }, this.whenKeyDPressed),
      new Trigger(
        Trigger.BROADCAST,
        { name: "blue-red-switch" },
        this.whenIReceiveBlueRedSwitch
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "red-blue-switch" },
        this.whenIReceiveRedBlueSwitch
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Soul-up" },
        this.whenIReceiveSoulUp
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Attack-activated" },
        this.whenIReceiveAttackActivated
      ),
      new Trigger(Trigger.KEY_PRESSED, { key: "w" }, this.whenKeyWPressed2),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "sans-turn" },
        this.whenIReceiveSansTurn
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "player-turn" },
        this.whenIReceivePlayerTurn
      ),
      new Trigger(Trigger.KEY_PRESSED, { key: "d" }, this.whenKeyDPressed2),
      new Trigger(Trigger.KEY_PRESSED, { key: "a" }, this.whenKeyAPressed2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "sans-turn" },
        this.whenIReceiveSansTurn2
      ),
      new Trigger(Trigger.KEY_PRESSED, { key: "w" }, this.whenKeyWPressed3),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenIReceiveGameStartNormalMode() {
    this.stage.vars.borderX = 55;
    this.stage.vars.borderNy = -88;
    this.stage.vars.borderY = 15;
    this.stage.vars.borderNx = -56;
    this.stage.vars.health = 92;
    this.costume = "player-heart-red";
    this.goto(-119, -92);
    this.effects.clear();
    this.visible = true;
    for (let i = 0; i < 2; i++) {
      yield* this.startSound("battlestart_1");
      this.visible = false;
      yield* this.wait(0.1);
      this.visible = true;
      yield;
    }
    yield* this.startSound("battlestart_2");
    yield* this.glide(0.3, -148, -114);
    this.effects.ghost = 0;
    for (let i = 0; i < 10; i++) {
      this.effects.ghost += 10;
      yield;
    }
    this.goto(0, -42);
    this.broadcast("player-normal-mode-ready");
  }

  *whenIReceiveBlackoutDoneNormalMode() {
    this.visible = true;
    this.costume = "player-heart-blue";
    this.goto(0, -42);
    yield* this.wait(0.4);
    this.goto(0, this.stage.vars.borderNy);
  }

  *whenKeyAPressed() {
    if (this.toString(this.stage.vars.movementAllowCheck) === "true") {
      if (this.compare(this.x, this.stage.vars.borderNx) > 0) {
        while (
          !(
            !this.keyPressed("a") ||
            this.compare(this.x, this.stage.vars.borderNx) < 0
          )
        ) {
          this.x -= 5;
          if (
            this.keyPressed("a") &&
            this.keyPressed("w") &&
            this.compare(this.y, this.stage.vars.borderY) < 0
          ) {
            this.x -= 0.1;
            this.y += 0.1;
          }
          if (
            this.keyPressed("a") &&
            this.keyPressed("s") &&
            this.compare(this.y, this.stage.vars.borderNy) > 0
          ) {
            this.x -= 0.1;
            this.y -= 0.1;
          }
          yield;
        }
      }
    }
  }

  *whenKeyWPressed() {
    if (this.toString(this.stage.vars.movementAllowCheck) === "true") {
      if (this.toString(this.stage.vars.soulType) === "red") {
        if (this.compare(this.y, this.stage.vars.borderY) < 0) {
          while (
            !(
              !this.keyPressed("w") ||
              this.compare(this.y, this.stage.vars.borderY) > 0
            )
          ) {
            this.y += 5;
            yield;
          }
        }
      }
      if (this.toString(this.stage.vars.soulType) === "blue") {
        while (!(this.toString(this.stage.vars.soulType) === "red")) {
          this.stage.vars.yVel -= 0.4;
          this.y += this.toNumber(this.stage.vars.yVel);
          if (
            this.compare(this.y, this.stage.vars.borderNy) === 0 ||
            this.compare(this.y, this.stage.vars.borderNy) < 0
          ) {
            this.y += this.toNumber(this.stage.vars.yVel) * -1;
            this.stage.vars.yVel = 0;
          }
          this.y -= 0.4;
          if (
            (this.compare(this.y, this.stage.vars.borderNy) === 0 ||
              this.compare(this.y, this.stage.vars.borderNy) < 0) &&
            this.keyPressed("w")
          ) {
            while (
              !(
                !this.keyPressed("w") ||
                this.y === 10 ||
                this.compare(this.y, 10) > 0 ||
                this.toNumber(this.stage.vars.yVel) === 8 ||
                this.compare(this.stage.vars.yVel, 7) > 0
              )
            ) {
              this.stage.vars.yVel++;
              this.y += this.toNumber(this.stage.vars.yVel);
              yield;
            }
          }
          this.y += 0.4;
          yield;
        }
      }
    }
  }

  *whenKeySPressed() {
    if (this.toString(this.stage.vars.movementAllowCheck) === "true") {
      if (this.toString(this.stage.vars.soulType) === "red") {
        if (this.compare(this.y, this.stage.vars.borderNy) > 0) {
          while (
            !(
              !this.keyPressed("s") ||
              this.compare(this.y, this.stage.vars.borderNy) < 0
            )
          ) {
            this.y -= 5;
            yield;
          }
        }
      }
    }
  }

  *whenKeyDPressed() {
    if (this.toString(this.stage.vars.movementAllowCheck) === "true") {
      if (this.toString(this.stage.vars.soulType) === "red") {
        if (this.compare(this.x, this.stage.vars.borderX) < 0) {
          while (
            !(
              !this.keyPressed("d") ||
              this.compare(this.x, this.stage.vars.borderX) > 0
            )
          ) {
            this.x += 6;
            if (
              this.keyPressed("d") &&
              this.keyPressed("w") &&
              this.compare(this.y, this.stage.vars.borderY) < 0
            ) {
              this.x += 0.1;
              this.y += 0.1;
            }
            if (
              this.keyPressed("d") &&
              this.keyPressed("s") &&
              this.compare(this.y, this.stage.vars.borderNy) > 0
            ) {
              this.x -= 0.1;
              this.y -= 0.1;
            }
            yield;
          }
        }
      }
      if (this.toString(this.stage.vars.soulType) === "blue") {
        if (this.compare(this.x, this.stage.vars.borderX) < 0) {
          while (
            !(
              !this.keyPressed("d") ||
              this.compare(this.x, this.stage.vars.borderX) > 0
            )
          ) {
            this.x += 5;
            yield;
          }
        }
      }
    }
  }

  *whenIReceiveBlueRedSwitch() {
    if (this.toString(this.stage.vars.soulType) === "red") {
      yield* this.startSound("soul-switch");
      this.costume = "player-heart-blue";
      this.stage.vars.soulType = "blue";
    }
  }

  *whenIReceiveRedBlueSwitch() {
    if (this.toString(this.stage.vars.soulType) === "blue") {
      yield* this.startSound("soul-switch");
      this.costume = "player-heart-red";
      this.stage.vars.soulType = "red";
    }
  }

  *whenIReceiveSoulUp() {
    yield* this.glide(0.1, this.x, this.toNumber(this.stage.vars.soulType));
  }

  *whenIReceiveAttackActivated() {
    while (true) {
      if (this.touching(this.sprites["WhiteBoneAttack1"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["GasterBlaster"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["GasterBlaster2"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["GasterBlaster3"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["GasterBlaster4"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["GasterBlaster5"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["GasterBlaster6"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["WhiteBoneAttack2"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["WhiteBoneAttack3"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["WhiteBoneAttack4"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["WhiteBoneAttack7"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["WhiteBoneAttack8"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["WhiteBoneAttack9"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["WhiteBoneAttack10"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      if (this.touching(this.sprites["WhiteBoneAttack10"].andClones())) {
        this.stage.vars.health--;
        yield* this.startSound("dmg_taken");
      }
      yield;
    }
  }

  *whenKeyWPressed2() {
    if (this.toString(this.stage.vars.fightSelect) === "1stTRUE") {
      this.goto(-75, -15);
    }
  }

  *whenKeySpacePressed() {
    if (this.toString(this.stage.vars.fightSelect) === "2ndTRUE") {
      this.goto(-185, -149);
    }
  }

  *whenIReceiveSansTurn() {
    this.moveBehind();
    this.goto(0, -87);
  }

  *whenIReceivePlayerTurn() {
    this.moveAhead();
    this.stage.vars.movementAllowCheck = "false";
    this.stage.vars.optionNumber = 1;
    this.stage.vars.fightSelect = 0;
    this.stage.vars.playerTurn = 1;
    while (!(this.toNumber(this.stage.vars.playerTurn) === 0)) {
      if (this.toNumber(this.stage.vars.optionNumber) === 1) {
        this.goto(-183, -151);
      }
      if (this.toNumber(this.stage.vars.optionNumber) === 2) {
        this.goto(-78, -150);
      }
      if (this.toNumber(this.stage.vars.optionNumber) === 3) {
        this.goto(26, -150);
      }
      if (this.toNumber(this.stage.vars.optionNumber) === 4) {
        this.goto(127, -148);
      }
      yield;
    }
  }

  *whenKeyDPressed2() {
    if (this.toNumber(this.stage.vars.playerTurn) === 1) {
      if (this.compare(this.stage.vars.optionNumber, 4) < 0) {
        this.stage.vars.optionNumber++;
      }
    }
  }

  *whenKeyAPressed2() {
    if (this.toNumber(this.stage.vars.playerTurn) === 1) {
      if (this.compare(this.stage.vars.optionNumber, 1) > 0) {
        this.stage.vars.optionNumber--;
      }
    }
  }

  *whenIReceiveSansTurn2() {
    this.stage.vars.movementAllowCheck = "true";
  }

  *whenKeyWPressed3() {
    if (this.toString(this.stage.vars.actSelect) === "1stTRUE") {
      this.goto(-75, -15);
    }
  }

  *whenKeySpacePressed2() {
    if (this.toString(this.stage.vars.actSelect) === "3rdTRUE") {
      this.goto(-78, -150);
    }
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.effects.clear();
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
