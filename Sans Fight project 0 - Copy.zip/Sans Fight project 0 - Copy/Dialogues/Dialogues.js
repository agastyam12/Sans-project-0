/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Dialogues extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "dialogue-1-frame1",
        "./Dialogues/costumes/dialogue-1-frame1.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame2",
        "./Dialogues/costumes/dialogue-1-frame2.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame3",
        "./Dialogues/costumes/dialogue-1-frame3.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame4",
        "./Dialogues/costumes/dialogue-1-frame4.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame5",
        "./Dialogues/costumes/dialogue-1-frame5.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame6",
        "./Dialogues/costumes/dialogue-1-frame6.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame7",
        "./Dialogues/costumes/dialogue-1-frame7.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame8",
        "./Dialogues/costumes/dialogue-1-frame8.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame9",
        "./Dialogues/costumes/dialogue-1-frame9.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame10",
        "./Dialogues/costumes/dialogue-1-frame10.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame11",
        "./Dialogues/costumes/dialogue-1-frame11.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame12",
        "./Dialogues/costumes/dialogue-1-frame12.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame13",
        "./Dialogues/costumes/dialogue-1-frame13.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame14",
        "./Dialogues/costumes/dialogue-1-frame14.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame15",
        "./Dialogues/costumes/dialogue-1-frame15.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame16",
        "./Dialogues/costumes/dialogue-1-frame16.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame17",
        "./Dialogues/costumes/dialogue-1-frame17.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame18",
        "./Dialogues/costumes/dialogue-1-frame18.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame19",
        "./Dialogues/costumes/dialogue-1-frame19.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame20",
        "./Dialogues/costumes/dialogue-1-frame20.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame21",
        "./Dialogues/costumes/dialogue-1-frame21.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame22",
        "./Dialogues/costumes/dialogue-1-frame22.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame23",
        "./Dialogues/costumes/dialogue-1-frame23.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame25",
        "./Dialogues/costumes/dialogue-1-frame25.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame26",
        "./Dialogues/costumes/dialogue-1-frame26.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame27",
        "./Dialogues/costumes/dialogue-1-frame27.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame28",
        "./Dialogues/costumes/dialogue-1-frame28.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-1-frame29",
        "./Dialogues/costumes/dialogue-1-frame29.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame1",
        "./Dialogues/costumes/dialogue-2-frame1.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame2",
        "./Dialogues/costumes/dialogue-2-frame2.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame3",
        "./Dialogues/costumes/dialogue-2-frame3.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame4",
        "./Dialogues/costumes/dialogue-2-frame4.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame5",
        "./Dialogues/costumes/dialogue-2-frame5.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame6",
        "./Dialogues/costumes/dialogue-2-frame6.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame7",
        "./Dialogues/costumes/dialogue-2-frame7.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame8",
        "./Dialogues/costumes/dialogue-2-frame8.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame9",
        "./Dialogues/costumes/dialogue-2-frame9.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame10",
        "./Dialogues/costumes/dialogue-2-frame10.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame11",
        "./Dialogues/costumes/dialogue-2-frame11.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame12",
        "./Dialogues/costumes/dialogue-2-frame12.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame13",
        "./Dialogues/costumes/dialogue-2-frame13.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame14",
        "./Dialogues/costumes/dialogue-2-frame14.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame15",
        "./Dialogues/costumes/dialogue-2-frame15.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-2-frame16",
        "./Dialogues/costumes/dialogue-2-frame16.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame17",
        "./Dialogues/costumes/dialogue-2-frame17.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame18-PAUSE",
        "./Dialogues/costumes/dialogue-2-frame18-PAUSE.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame18",
        "./Dialogues/costumes/dialogue-2-frame18.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame19",
        "./Dialogues/costumes/dialogue-2-frame19.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame20",
        "./Dialogues/costumes/dialogue-2-frame20.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame21",
        "./Dialogues/costumes/dialogue-2-frame21.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame22",
        "./Dialogues/costumes/dialogue-2-frame22.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame23",
        "./Dialogues/costumes/dialogue-2-frame23.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame24",
        "./Dialogues/costumes/dialogue-2-frame24.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame25",
        "./Dialogues/costumes/dialogue-2-frame25.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame26",
        "./Dialogues/costumes/dialogue-2-frame26.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame27",
        "./Dialogues/costumes/dialogue-2-frame27.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame28",
        "./Dialogues/costumes/dialogue-2-frame28.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame35",
        "./Dialogues/costumes/dialogue-2-frame35.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame30",
        "./Dialogues/costumes/dialogue-2-frame30.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame31",
        "./Dialogues/costumes/dialogue-2-frame31.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame32",
        "./Dialogues/costumes/dialogue-2-frame32.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame33",
        "./Dialogues/costumes/dialogue-2-frame33.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame34",
        "./Dialogues/costumes/dialogue-2-frame34.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame36",
        "./Dialogues/costumes/dialogue-2-frame36.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-2-frame37",
        "./Dialogues/costumes/dialogue-2-frame37.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "dialogue-3-frame1",
        "./Dialogues/costumes/dialogue-3-frame1.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame2",
        "./Dialogues/costumes/dialogue-3-frame2.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame3",
        "./Dialogues/costumes/dialogue-3-frame3.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame4",
        "./Dialogues/costumes/dialogue-3-frame4.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame5",
        "./Dialogues/costumes/dialogue-3-frame5.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame6",
        "./Dialogues/costumes/dialogue-3-frame6.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame7",
        "./Dialogues/costumes/dialogue-3-frame7.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame8",
        "./Dialogues/costumes/dialogue-3-frame8.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame9",
        "./Dialogues/costumes/dialogue-3-frame9.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame10",
        "./Dialogues/costumes/dialogue-3-frame10.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame11",
        "./Dialogues/costumes/dialogue-3-frame11.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame12",
        "./Dialogues/costumes/dialogue-3-frame12.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame13",
        "./Dialogues/costumes/dialogue-3-frame13.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame14",
        "./Dialogues/costumes/dialogue-3-frame14.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame15",
        "./Dialogues/costumes/dialogue-3-frame15.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame16",
        "./Dialogues/costumes/dialogue-3-frame16.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame17",
        "./Dialogues/costumes/dialogue-3-frame17.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame18",
        "./Dialogues/costumes/dialogue-3-frame18.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame19",
        "./Dialogues/costumes/dialogue-3-frame19.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame20",
        "./Dialogues/costumes/dialogue-3-frame20.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame21",
        "./Dialogues/costumes/dialogue-3-frame21.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame22",
        "./Dialogues/costumes/dialogue-3-frame22.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame23",
        "./Dialogues/costumes/dialogue-3-frame23.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame24",
        "./Dialogues/costumes/dialogue-3-frame24.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame25-PAUSE",
        "./Dialogues/costumes/dialogue-3-frame25-PAUSE.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame26",
        "./Dialogues/costumes/dialogue-3-frame26.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame27",
        "./Dialogues/costumes/dialogue-3-frame27.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame28",
        "./Dialogues/costumes/dialogue-3-frame28.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame25",
        "./Dialogues/costumes/dialogue-3-frame25.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame29",
        "./Dialogues/costumes/dialogue-3-frame29.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame30",
        "./Dialogues/costumes/dialogue-3-frame30.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame31",
        "./Dialogues/costumes/dialogue-3-frame31.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame32",
        "./Dialogues/costumes/dialogue-3-frame32.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame33",
        "./Dialogues/costumes/dialogue-3-frame33.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame34",
        "./Dialogues/costumes/dialogue-3-frame34.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame35",
        "./Dialogues/costumes/dialogue-3-frame35.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame36",
        "./Dialogues/costumes/dialogue-3-frame36.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame37",
        "./Dialogues/costumes/dialogue-3-frame37.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame38",
        "./Dialogues/costumes/dialogue-3-frame38.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame39",
        "./Dialogues/costumes/dialogue-3-frame39.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-3-frame40",
        "./Dialogues/costumes/dialogue-3-frame40.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame1",
        "./Dialogues/costumes/dialogue-4-frame1.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame2",
        "./Dialogues/costumes/dialogue-4-frame2.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame3",
        "./Dialogues/costumes/dialogue-4-frame3.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame4",
        "./Dialogues/costumes/dialogue-4-frame4.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame5",
        "./Dialogues/costumes/dialogue-4-frame5.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame6",
        "./Dialogues/costumes/dialogue-4-frame6.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame7",
        "./Dialogues/costumes/dialogue-4-frame7.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame8",
        "./Dialogues/costumes/dialogue-4-frame8.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame9",
        "./Dialogues/costumes/dialogue-4-frame9.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame10",
        "./Dialogues/costumes/dialogue-4-frame10.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame11",
        "./Dialogues/costumes/dialogue-4-frame11.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame12",
        "./Dialogues/costumes/dialogue-4-frame12.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame13",
        "./Dialogues/costumes/dialogue-4-frame13.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame14",
        "./Dialogues/costumes/dialogue-4-frame14.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame15",
        "./Dialogues/costumes/dialogue-4-frame15.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame16",
        "./Dialogues/costumes/dialogue-4-frame16.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame17",
        "./Dialogues/costumes/dialogue-4-frame17.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame18",
        "./Dialogues/costumes/dialogue-4-frame18.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame19",
        "./Dialogues/costumes/dialogue-4-frame19.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame20",
        "./Dialogues/costumes/dialogue-4-frame20.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame21",
        "./Dialogues/costumes/dialogue-4-frame21.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame22",
        "./Dialogues/costumes/dialogue-4-frame22.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame23",
        "./Dialogues/costumes/dialogue-4-frame23.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame24",
        "./Dialogues/costumes/dialogue-4-frame24.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame25",
        "./Dialogues/costumes/dialogue-4-frame25.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame27",
        "./Dialogues/costumes/dialogue-4-frame27.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame28",
        "./Dialogues/costumes/dialogue-4-frame28.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame29",
        "./Dialogues/costumes/dialogue-4-frame29.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame30",
        "./Dialogues/costumes/dialogue-4-frame30.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame31",
        "./Dialogues/costumes/dialogue-4-frame31.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame33",
        "./Dialogues/costumes/dialogue-4-frame33.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame34",
        "./Dialogues/costumes/dialogue-4-frame34.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame35",
        "./Dialogues/costumes/dialogue-4-frame35.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame36",
        "./Dialogues/costumes/dialogue-4-frame36.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame38",
        "./Dialogues/costumes/dialogue-4-frame38.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "dialogue-4-frame39",
        "./Dialogues/costumes/dialogue-4-frame39.png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "here_we_goFRAME1",
        "./Dialogues/costumes/here_we_goFRAME1.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "here_we_goFRAME2",
        "./Dialogues/costumes/here_we_goFRAME2.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "here_we_goFRAME3",
        "./Dialogues/costumes/here_we_goFRAME3.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "here_we_goFRAME4",
        "./Dialogues/costumes/here_we_goFRAME4.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "here_we_goFRAME5",
        "./Dialogues/costumes/here_we_goFRAME5.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "here_we_goFRAME6",
        "./Dialogues/costumes/here_we_goFRAME6.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "here_we_goFRAME7",
        "./Dialogues/costumes/here_we_goFRAME7.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "here_we_goFRAME8",
        "./Dialogues/costumes/here_we_goFRAME8.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "here_we_goFRAME9",
        "./Dialogues/costumes/here_we_goFRAME9.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "here_we_goFRAME10",
        "./Dialogues/costumes/here_we_goFRAME10.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)",
        "./Dialogues/costumes/undertale_text_box (5).png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)2",
        "./Dialogues/costumes/undertale_text_box (5)2.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)3",
        "./Dialogues/costumes/undertale_text_box (5)3.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)4",
        "./Dialogues/costumes/undertale_text_box (5)4.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)6",
        "./Dialogues/costumes/undertale_text_box (5)6.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)26",
        "./Dialogues/costumes/undertale_text_box (5)26.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)27",
        "./Dialogues/costumes/undertale_text_box (5)27.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)28",
        "./Dialogues/costumes/undertale_text_box (5)28.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)29",
        "./Dialogues/costumes/undertale_text_box (5)29.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)30",
        "./Dialogues/costumes/undertale_text_box (5)30.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)31",
        "./Dialogues/costumes/undertale_text_box (5)31.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)32",
        "./Dialogues/costumes/undertale_text_box (5)32.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)33",
        "./Dialogues/costumes/undertale_text_box (5)33.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)34",
        "./Dialogues/costumes/undertale_text_box (5)34.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)35",
        "./Dialogues/costumes/undertale_text_box (5)35.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)37",
        "./Dialogues/costumes/undertale_text_box (5)37.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)38",
        "./Dialogues/costumes/undertale_text_box (5)38.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)39",
        "./Dialogues/costumes/undertale_text_box (5)39.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)40",
        "./Dialogues/costumes/undertale_text_box (5)40.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)41",
        "./Dialogues/costumes/undertale_text_box (5)41.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)42",
        "./Dialogues/costumes/undertale_text_box (5)42.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)43",
        "./Dialogues/costumes/undertale_text_box (5)43.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)44",
        "./Dialogues/costumes/undertale_text_box (5)44.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)45",
        "./Dialogues/costumes/undertale_text_box (5)45.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)46",
        "./Dialogues/costumes/undertale_text_box (5)46.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)47",
        "./Dialogues/costumes/undertale_text_box (5)47.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)48",
        "./Dialogues/costumes/undertale_text_box (5)48.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)49",
        "./Dialogues/costumes/undertale_text_box (5)49.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)50",
        "./Dialogues/costumes/undertale_text_box (5)50.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)51",
        "./Dialogues/costumes/undertale_text_box (5)51.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)52",
        "./Dialogues/costumes/undertale_text_box (5)52.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)53",
        "./Dialogues/costumes/undertale_text_box (5)53.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)54",
        "./Dialogues/costumes/undertale_text_box (5)54.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)55",
        "./Dialogues/costumes/undertale_text_box (5)55.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)56",
        "./Dialogues/costumes/undertale_text_box (5)56.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)58",
        "./Dialogues/costumes/undertale_text_box (5)58.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)59",
        "./Dialogues/costumes/undertale_text_box (5)59.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)60",
        "./Dialogues/costumes/undertale_text_box (5)60.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)61",
        "./Dialogues/costumes/undertale_text_box (5)61.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)62",
        "./Dialogues/costumes/undertale_text_box (5)62.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)63",
        "./Dialogues/costumes/undertale_text_box (5)63.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)64",
        "./Dialogues/costumes/undertale_text_box (5)64.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)65",
        "./Dialogues/costumes/undertale_text_box (5)65.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)66",
        "./Dialogues/costumes/undertale_text_box (5)66.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)67",
        "./Dialogues/costumes/undertale_text_box (5)67.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)68",
        "./Dialogues/costumes/undertale_text_box (5)68.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)69",
        "./Dialogues/costumes/undertale_text_box (5)69.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)70",
        "./Dialogues/costumes/undertale_text_box (5)70.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)71",
        "./Dialogues/costumes/undertale_text_box (5)71.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)74",
        "./Dialogues/costumes/undertale_text_box (5)74.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)73",
        "./Dialogues/costumes/undertale_text_box (5)73.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)75",
        "./Dialogues/costumes/undertale_text_box (5)75.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)77",
        "./Dialogues/costumes/undertale_text_box (5)77.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)78",
        "./Dialogues/costumes/undertale_text_box (5)78.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)79",
        "./Dialogues/costumes/undertale_text_box (5)79.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (5)80",
        "./Dialogues/costumes/undertale_text_box (5)80.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)",
        "./Dialogues/costumes/undertale_text_box (8).png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)2",
        "./Dialogues/costumes/undertale_text_box (8)2.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)3",
        "./Dialogues/costumes/undertale_text_box (8)3.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)4",
        "./Dialogues/costumes/undertale_text_box (8)4.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)5",
        "./Dialogues/costumes/undertale_text_box (8)5.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)13",
        "./Dialogues/costumes/undertale_text_box (8)13.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)15",
        "./Dialogues/costumes/undertale_text_box (8)15.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)14",
        "./Dialogues/costumes/undertale_text_box (8)14.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)16",
        "./Dialogues/costumes/undertale_text_box (8)16.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)17",
        "./Dialogues/costumes/undertale_text_box (8)17.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)18",
        "./Dialogues/costumes/undertale_text_box (8)18.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)19",
        "./Dialogues/costumes/undertale_text_box (8)19.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)21",
        "./Dialogues/costumes/undertale_text_box (8)21.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)20",
        "./Dialogues/costumes/undertale_text_box (8)20.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)22",
        "./Dialogues/costumes/undertale_text_box (8)22.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)23",
        "./Dialogues/costumes/undertale_text_box (8)23.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)24",
        "./Dialogues/costumes/undertale_text_box (8)24.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)25",
        "./Dialogues/costumes/undertale_text_box (8)25.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)26",
        "./Dialogues/costumes/undertale_text_box (8)26.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)27",
        "./Dialogues/costumes/undertale_text_box (8)27.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)28",
        "./Dialogues/costumes/undertale_text_box (8)28.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)29",
        "./Dialogues/costumes/undertale_text_box (8)29.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)30",
        "./Dialogues/costumes/undertale_text_box (8)30.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)31",
        "./Dialogues/costumes/undertale_text_box (8)31.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)32",
        "./Dialogues/costumes/undertale_text_box (8)32.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)33",
        "./Dialogues/costumes/undertale_text_box (8)33.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)35",
        "./Dialogues/costumes/undertale_text_box (8)35.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)34",
        "./Dialogues/costumes/undertale_text_box (8)34.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)37",
        "./Dialogues/costumes/undertale_text_box (8)37.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)38",
        "./Dialogues/costumes/undertale_text_box (8)38.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)39",
        "./Dialogues/costumes/undertale_text_box (8)39.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)40",
        "./Dialogues/costumes/undertale_text_box (8)40.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)41",
        "./Dialogues/costumes/undertale_text_box (8)41.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)42",
        "./Dialogues/costumes/undertale_text_box (8)42.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)43",
        "./Dialogues/costumes/undertale_text_box (8)43.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)45",
        "./Dialogues/costumes/undertale_text_box (8)45.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)44",
        "./Dialogues/costumes/undertale_text_box (8)44.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)46",
        "./Dialogues/costumes/undertale_text_box (8)46.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)47",
        "./Dialogues/costumes/undertale_text_box (8)47.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)49",
        "./Dialogues/costumes/undertale_text_box (8)49.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)48",
        "./Dialogues/costumes/undertale_text_box (8)48.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)51",
        "./Dialogues/costumes/undertale_text_box (8)51.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)50",
        "./Dialogues/costumes/undertale_text_box (8)50.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)52",
        "./Dialogues/costumes/undertale_text_box (8)52.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)53",
        "./Dialogues/costumes/undertale_text_box (8)53.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (8)55",
        "./Dialogues/costumes/undertale_text_box (8)55.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)2",
        "./Dialogues/costumes/undertale_text_box (9)2.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)3",
        "./Dialogues/costumes/undertale_text_box (9)3.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)12",
        "./Dialogues/costumes/undertale_text_box (9)12.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)13",
        "./Dialogues/costumes/undertale_text_box (9)13.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)14",
        "./Dialogues/costumes/undertale_text_box (9)14.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)15",
        "./Dialogues/costumes/undertale_text_box (9)15.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)16",
        "./Dialogues/costumes/undertale_text_box (9)16.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)17",
        "./Dialogues/costumes/undertale_text_box (9)17.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)18",
        "./Dialogues/costumes/undertale_text_box (9)18.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)19",
        "./Dialogues/costumes/undertale_text_box (9)19.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)20",
        "./Dialogues/costumes/undertale_text_box (9)20.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)21",
        "./Dialogues/costumes/undertale_text_box (9)21.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)22",
        "./Dialogues/costumes/undertale_text_box (9)22.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)23",
        "./Dialogues/costumes/undertale_text_box (9)23.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)24",
        "./Dialogues/costumes/undertale_text_box (9)24.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)45",
        "./Dialogues/costumes/undertale_text_box (9)45.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)46",
        "./Dialogues/costumes/undertale_text_box (9)46.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)47",
        "./Dialogues/costumes/undertale_text_box (9)47.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)49",
        "./Dialogues/costumes/undertale_text_box (9)49.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)48",
        "./Dialogues/costumes/undertale_text_box (9)48.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)50",
        "./Dialogues/costumes/undertale_text_box (9)50.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)51",
        "./Dialogues/costumes/undertale_text_box (9)51.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)52",
        "./Dialogues/costumes/undertale_text_box (9)52.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)53",
        "./Dialogues/costumes/undertale_text_box (9)53.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)54",
        "./Dialogues/costumes/undertale_text_box (9)54.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)55",
        "./Dialogues/costumes/undertale_text_box (9)55.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)56",
        "./Dialogues/costumes/undertale_text_box (9)56.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)57",
        "./Dialogues/costumes/undertale_text_box (9)57.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)58",
        "./Dialogues/costumes/undertale_text_box (9)58.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)60",
        "./Dialogues/costumes/undertale_text_box (9)60.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)59",
        "./Dialogues/costumes/undertale_text_box (9)59.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)61",
        "./Dialogues/costumes/undertale_text_box (9)61.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)63",
        "./Dialogues/costumes/undertale_text_box (9)63.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)62",
        "./Dialogues/costumes/undertale_text_box (9)62.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)64",
        "./Dialogues/costumes/undertale_text_box (9)64.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)65",
        "./Dialogues/costumes/undertale_text_box (9)65.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)66",
        "./Dialogues/costumes/undertale_text_box (9)66.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)67",
        "./Dialogues/costumes/undertale_text_box (9)67.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)68",
        "./Dialogues/costumes/undertale_text_box (9)68.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)69",
        "./Dialogues/costumes/undertale_text_box (9)69.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)70",
        "./Dialogues/costumes/undertale_text_box (9)70.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)71",
        "./Dialogues/costumes/undertale_text_box (9)71.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)72",
        "./Dialogues/costumes/undertale_text_box (9)72.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)73",
        "./Dialogues/costumes/undertale_text_box (9)73.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)74",
        "./Dialogues/costumes/undertale_text_box (9)74.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)94",
        "./Dialogues/costumes/undertale_text_box (9)94.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)95",
        "./Dialogues/costumes/undertale_text_box (9)95.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)96",
        "./Dialogues/costumes/undertale_text_box (9)96.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)97",
        "./Dialogues/costumes/undertale_text_box (9)97.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)98",
        "./Dialogues/costumes/undertale_text_box (9)98.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)99",
        "./Dialogues/costumes/undertale_text_box (9)99.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)100",
        "./Dialogues/costumes/undertale_text_box (9)100.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)79",
        "./Dialogues/costumes/undertale_text_box (9)79.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)101",
        "./Dialogues/costumes/undertale_text_box (9)101.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)102",
        "./Dialogues/costumes/undertale_text_box (9)102.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)104",
        "./Dialogues/costumes/undertale_text_box (9)104.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)105",
        "./Dialogues/costumes/undertale_text_box (9)105.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)106",
        "./Dialogues/costumes/undertale_text_box (9)106.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)107",
        "./Dialogues/costumes/undertale_text_box (9)107.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)108",
        "./Dialogues/costumes/undertale_text_box (9)108.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)109",
        "./Dialogues/costumes/undertale_text_box (9)109.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)110",
        "./Dialogues/costumes/undertale_text_box (9)110.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)111",
        "./Dialogues/costumes/undertale_text_box (9)111.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)112",
        "./Dialogues/costumes/undertale_text_box (9)112.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)113",
        "./Dialogues/costumes/undertale_text_box (9)113.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)114",
        "./Dialogues/costumes/undertale_text_box (9)114.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)115",
        "./Dialogues/costumes/undertale_text_box (9)115.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)116",
        "./Dialogues/costumes/undertale_text_box (9)116.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)117",
        "./Dialogues/costumes/undertale_text_box (9)117.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)118",
        "./Dialogues/costumes/undertale_text_box (9)118.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)119",
        "./Dialogues/costumes/undertale_text_box (9)119.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)120",
        "./Dialogues/costumes/undertale_text_box (9)120.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)121",
        "./Dialogues/costumes/undertale_text_box (9)121.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)122",
        "./Dialogues/costumes/undertale_text_box (9)122.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)123",
        "./Dialogues/costumes/undertale_text_box (9)123.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)124",
        "./Dialogues/costumes/undertale_text_box (9)124.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)125",
        "./Dialogues/costumes/undertale_text_box (9)125.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)103",
        "./Dialogues/costumes/undertale_text_box (9)103.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (9)127",
        "./Dialogues/costumes/undertale_text_box (9)127.png",
        { x: 291, y: 78 }
      ),
    ];

    this.sounds = [new Sound("txtsans", "./Dialogues/sounds/txtsans.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "dialogues-1to4-normal-mode" },
        this.whenIReceiveDialogues1to4NormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "here we go" },
        this.whenIReceiveHereWeGo
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "dialogues-5" },
        this.whenIReceiveDialogues5
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "dialogues-end-part1" },
        this.whenIReceiveDialoguesEndPart1
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenIReceiveDialogues1to4NormalMode() {
    this.broadcast("Sans-eyes-closed-on-normal-mode");
    this.audioEffects.volume = 100;
    this.audioEffects.pitch = 0;
    this.visible = true;
    this.moveAhead();
    yield* this.dialogues1to4();
    this.broadcast("dialogues-1to4-normal-mode-done");
  }

  *sansTalk() {
    yield* this.wait(0.015);
    yield* this.startSound("txtsans");
    this.costumeNumber++;
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *dialogues1to4() {
    this.costume = "dialogue-1-frame1";
    for (let i = 0; i < 27; i++) {
      yield* this.sansTalk();
      yield;
    }
    yield* this.wait(1);
    this.costume = "dialogue-2-frame1";
    for (let i = 0; i < 17; i++) {
      yield* this.sansTalk();
      yield;
    }
    yield* this.wait(1);
    for (let i = 0; i < 19; i++) {
      yield* this.sansTalk();
      yield;
    }
    yield* this.wait(1);
    this.costume = "dialogue-3-frame1";
    for (let i = 0; i < 20; i++) {
      yield* this.sansTalk();
      yield;
    }
    yield* this.wait(0.5);
    for (let i = 0; i < 20; i++) {
      yield* this.sansTalk();
      yield;
    }
    yield* this.wait(1);
    this.broadcast("Sans-eyes-false-on-normal-mode");
    this.costume = "dialogue-4-frame1";
    this.audioEffects.pitch -= 10;
    for (let i = 0; i < 35; i++) {
      yield* this.startSound("txtsans");
      yield* this.wait(0.015);
      this.costumeNumber++;
      yield;
    }
    this.audioEffects.pitch += 10;
  }

  *whenIReceiveHereWeGo() {
    this.visible = true;
    this.costume = "here_we_goFRAME1";
    for (let i = 0; i < 9; i++) {
      yield* this.sansTalk();
      yield;
    }
    yield* this.wait(1);
    this.visible = false;
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenIReceiveDialogues5() {
    this.visible = true;
    this.costume = "undertale_text_box (5)";
    for (let i = 0; i < 4; i++) {
      yield* this.sansTalk();
      yield;
    }
    yield* this.wait(1);
    for (let i = 0; i < 51; i++) {
      yield* this.sansTalk();
      yield;
    }
    yield* this.wait(1);
    this.visible = false;
  }

  *whenIReceiveDialoguesEndPart1() {
    this.visible = true;
    this.costume = "undertale_text_box (8)";
    for (let i = 0; i < 4; i++) {
      yield* this.sansTalk();
      yield;
    }
    yield* this.wait(1);
    for (let i = 0; i < 41; i++) {
      yield* this.sansTalk();
      yield;
    }
    yield* this.wait(1);
    for (let i = 0; i < 15; i++) {
      yield* this.sansTalk();
      yield;
    }
    yield* this.wait(1);
    for (let i = 0; i < 30; i++) {
      yield* this.sansTalk();
      yield;
    }
    yield* this.wait(1);
    for (let i = 0; i < 34; i++) {
      yield* this.sansTalk();
      yield;
    }
    yield* this.wait(3);
    this.broadcast("Game complete");
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.stage.costume = "Game complete";
    this.visible = false;
  }
}
