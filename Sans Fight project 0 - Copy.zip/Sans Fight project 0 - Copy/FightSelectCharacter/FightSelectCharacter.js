/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class FightSelectCharacter extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "undertale_text_box (3)",
        "./FightSelectCharacter/costumes/undertale_text_box (3).png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "undertale_text_box (2)",
        "./FightSelectCharacter/costumes/undertale_text_box (2).png",
        { x: 289, y: 76 }
      ),
    ];

    this.sounds = [
      new Sound("select", "./FightSelectCharacter/sounds/select.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.KEY_PRESSED, { key: "w" }, this.whenKeyWPressed),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Fight-select-character" },
        this.whenIReceiveFightSelectCharacter
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenKeyWPressed() {
    if (this.toString(this.stage.vars.fightSelect) === "1stTRUE") {
      this.stage.vars.fightSelect = "2ndTRUE";
      this.costume = "undertale_text_box (3)";
    }
  }

  *whenKeySpacePressed() {
    if (this.toString(this.stage.vars.fightSelect) === "2ndTRUE") {
      yield* this.wait(0.1);
      yield* this.startSound("select");
      this.stage.vars.fightSelect = "3rdTRUE";
      this.broadcast("Fight selected");
      this.visible = false;
    }
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenIReceiveFightSelectCharacter() {
    this.visible = true;
    this.costume = "undertale_text_box (2)";
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
