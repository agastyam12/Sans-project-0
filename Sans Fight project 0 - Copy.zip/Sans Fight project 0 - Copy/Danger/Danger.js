/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Danger extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Danger-red", "./Danger/costumes/Danger-red.svg", {
        x: 18.75,
        y: 57.75,
      }),
      new Costume("Danger-orange", "./Danger/costumes/Danger-orange.svg", {
        x: 18.75,
        y: 57.75,
      }),
    ];

    this.sounds = [new Sound("warn", "./Danger/sounds/warn.mp3")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "bone-floor" },
        this.whenIReceiveBoneFloor
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "player-normal-mode-ready" },
        this.whenIReceivePlayerNormalModeReady
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenIReceiveBoneFloor() {
    yield* this.wait(0.1);
    this.visible = true;
    this.size = 110;
    this.goto(0, -80);
    this.direction = 180;
    yield* this.flash();
    this.visible = false;
  }

  *flash() {
    for (let i = 0; i < 3; i++) {
      yield* this.wait(0.05);
      this.costume = "Danger-red";
      yield* this.wait(0.05);
      this.costume = "Danger-orange";
      yield;
    }
    this.costume = "Danger-red";
  }

  *whenIReceivePlayerNormalModeReady() {
    this.moveAhead();
    this.moveBehind(1);
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
