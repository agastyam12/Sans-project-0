/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sans extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "idle-animation-eyes-true-frame1",
        "./Sans/costumes/idle-animation-eyes-true-frame1.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-true-frame2",
        "./Sans/costumes/idle-animation-eyes-true-frame2.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-frame3",
        "./Sans/costumes/idle-animation-eyes-true-frame3.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-frame4",
        "./Sans/costumes/idle-animation-eyes-true-frame4.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-frame5",
        "./Sans/costumes/idle-animation-eyes-true-frame5.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-true-frame6",
        "./Sans/costumes/idle-animation-eyes-true-frame6.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "idle-animation-eyes-true-frame7",
        "./Sans/costumes/idle-animation-eyes-true-frame7.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "idle-animation-eyes-true-frame8",
        "./Sans/costumes/idle-animation-eyes-true-frame8.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-true-frame9",
        "./Sans/costumes/idle-animation-eyes-true-frame9.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-frame10",
        "./Sans/costumes/idle-animation-eyes-true-frame10.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-frame11",
        "./Sans/costumes/idle-animation-eyes-true-frame11.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-frame12",
        "./Sans/costumes/idle-animation-eyes-true-frame12.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-true-frame13",
        "./Sans/costumes/idle-animation-eyes-true-frame13.png",
        { x: 108, y: 143 }
      ),
      new Costume("closed eyes", "./Sans/costumes/closed eyes.png", {
        x: 108,
        y: 143,
      }),
      new Costume("closed eye-1eye", "./Sans/costumes/closed eye-1eye.png", {
        x: 108,
        y: 143,
      }),
      new Costume(
        "idle-animation-eyes-false-frame1",
        "./Sans/costumes/idle-animation-eyes-false-frame1.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-false-frame2",
        "./Sans/costumes/idle-animation-eyes-false-frame2.svg",
        { x: 54, y: 72.5 }
      ),
      new Costume(
        "idle-animation-eyes-false-frame3",
        "./Sans/costumes/idle-animation-eyes-false-frame3.svg",
        { x: 54, y: 72.5 }
      ),
      new Costume(
        "idle-animation-eyes-false-frame4",
        "./Sans/costumes/idle-animation-eyes-false-frame4.svg",
        { x: 54, y: 72.5 }
      ),
      new Costume(
        "idle-animation-eyes-false-frame5",
        "./Sans/costumes/idle-animation-eyes-false-frame5.svg",
        { x: 54, y: 72 }
      ),
      new Costume(
        "idle-animation-eyes-false-frame6",
        "./Sans/costumes/idle-animation-eyes-false-frame6.svg",
        { x: 54, y: 71.5 }
      ),
      new Costume(
        "idle-animation-eyes-false-frame7",
        "./Sans/costumes/idle-animation-eyes-false-frame7.svg",
        { x: 54, y: 71.5 }
      ),
      new Costume(
        "idle-animation-eyes-false-frame8",
        "./Sans/costumes/idle-animation-eyes-false-frame8.svg",
        { x: 54, y: 72 }
      ),
      new Costume(
        "idle-animation-eyes-false-frame9",
        "./Sans/costumes/idle-animation-eyes-false-frame9.svg",
        { x: 54, y: 72.5 }
      ),
      new Costume(
        "idle-animation-eyes-false-frame10",
        "./Sans/costumes/idle-animation-eyes-false-frame10.svg",
        { x: 54, y: 72.5 }
      ),
      new Costume(
        "idle-animation-eyes-false-frame11",
        "./Sans/costumes/idle-animation-eyes-false-frame11.svg",
        { x: 54.00000000000003, y: 72 }
      ),
      new Costume(
        "idle-animation-eyes-false-frame12",
        "./Sans/costumes/idle-animation-eyes-false-frame12.svg",
        { x: 54, y: 72.5 }
      ),
      new Costume(
        "idle-animation-eyes-false-frame13",
        "./Sans/costumes/idle-animation-eyes-false-frame13.svg",
        { x: 54, y: 71.5 }
      ),
      new Costume(
        "idle-animation-eyes-true-1s-frame1",
        "./Sans/costumes/idle-animation-eyes-true-1s-frame1.svg",
        { x: 54, y: 72 }
      ),
      new Costume(
        "idle-animation-eyes-true-1s-frame2",
        "./Sans/costumes/idle-animation-eyes-true-1s-frame2.svg",
        { x: 54, y: 72.5 }
      ),
      new Costume(
        "idle-animation-eyes-true-1s-frame3",
        "./Sans/costumes/idle-animation-eyes-true-1s-frame3.svg",
        { x: 54, y: 72.5 }
      ),
      new Costume(
        "idle-animation-eyes-true-1s-frame4",
        "./Sans/costumes/idle-animation-eyes-true-1s-frame4.svg",
        { x: 54, y: 72 }
      ),
      new Costume(
        "idle-animation-eyes-true-1s-frame5",
        "./Sans/costumes/idle-animation-eyes-true-1s-frame5.svg",
        { x: 54, y: 71.5 }
      ),
      new Costume(
        "idle-animation-eyes-true-1s-frame6",
        "./Sans/costumes/idle-animation-eyes-true-1s-frame6.svg",
        { x: 54, y: 72 }
      ),
      new Costume(
        "idle-animation-eyes-true-1s-frame7",
        "./Sans/costumes/idle-animation-eyes-true-1s-frame7.svg",
        { x: 54, y: 71.5 }
      ),
      new Costume(
        "idle-animation-eyes-true-1s-frame8",
        "./Sans/costumes/idle-animation-eyes-true-1s-frame8.svg",
        { x: 54.00000000000003, y: 72.5 }
      ),
      new Costume(
        "idle-animation-eyes-true-1s-frame9",
        "./Sans/costumes/idle-animation-eyes-true-1s-frame9.svg",
        { x: 54, y: 72.5 }
      ),
      new Costume(
        "idle-animation-eyes-true-1s-frame10",
        "./Sans/costumes/idle-animation-eyes-true-1s-frame10.svg",
        { x: 54, y: 72 }
      ),
      new Costume(
        "idle-animation-eyes-true-1s-frame11",
        "./Sans/costumes/idle-animation-eyes-true-1s-frame11.svg",
        { x: 54, y: 72.5 }
      ),
      new Costume(
        "idle-animation-eyes-true-1s-frame12",
        "./Sans/costumes/idle-animation-eyes-true-1s-frame12.svg",
        { x: 54, y: 72.5 }
      ),
      new Costume(
        "idle-animation-eyes-true-1s-frame13",
        "./Sans/costumes/idle-animation-eyes-true-1s-frame13.svg",
        { x: 54, y: 71.5 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-frame1",
        "./Sans/costumes/idle-animation-eyes-ultra-frame1.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-frame2",
        "./Sans/costumes/idle-animation-eyes-ultra-frame2.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-frame3",
        "./Sans/costumes/idle-animation-eyes-ultra-frame3.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-frame4",
        "./Sans/costumes/idle-animation-eyes-ultra-frame4.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-frame5",
        "./Sans/costumes/idle-animation-eyes-ultra-frame5.png",
        { x: 109, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-frame6",
        "./Sans/costumes/idle-animation-eyes-ultra-frame6.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-frame7",
        "./Sans/costumes/idle-animation-eyes-ultra-frame7.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-frame8",
        "./Sans/costumes/idle-animation-eyes-ultra-frame8.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-frame9",
        "./Sans/costumes/idle-animation-eyes-ultra-frame9.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-frame10",
        "./Sans/costumes/idle-animation-eyes-ultra-frame10.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-frame11",
        "./Sans/costumes/idle-animation-eyes-ultra-frame11.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-frame12",
        "./Sans/costumes/idle-animation-eyes-ultra-frame12.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-frame13",
        "./Sans/costumes/idle-animation-eyes-ultra-frame13.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "Idle-animation-eyes-ultra-1s-frame1idle-animation13",
        "./Sans/costumes/Idle-animation-eyes-ultra-1s-frame1idle-animation13.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "Idle-animation-eyes-ultra-1s-frame2",
        "./Sans/costumes/Idle-animation-eyes-ultra-1s-frame2.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "Idle-animation-eyes-ultra-1s-frame3",
        "./Sans/costumes/Idle-animation-eyes-ultra-1s-frame3.svg",
        { x: 54, y: 72 }
      ),
      new Costume(
        "Idle-animation-eyes-ultra-1s-frame4",
        "./Sans/costumes/Idle-animation-eyes-ultra-1s-frame4.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "Idle-animation-eyes-ultra-1s-frame5",
        "./Sans/costumes/Idle-animation-eyes-ultra-1s-frame5.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "Idle-animation-eyes-ultra-1s-frame6",
        "./Sans/costumes/Idle-animation-eyes-ultra-1s-frame6.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "Idle-animation-eyes-ultra-1s-frame7",
        "./Sans/costumes/Idle-animation-eyes-ultra-1s-frame7.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "Idle-animation-eyes-ultra-1s-frame8",
        "./Sans/costumes/Idle-animation-eyes-ultra-1s-frame8.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "Idle-animation-eyes-ultra-1s-frame9",
        "./Sans/costumes/Idle-animation-eyes-ultra-1s-frame9.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "Idle-animation-eyes-ultra-1s-frame10",
        "./Sans/costumes/Idle-animation-eyes-ultra-1s-frame10.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "Idle-animation-eyes-ultra-1s-frame11",
        "./Sans/costumes/Idle-animation-eyes-ultra-1s-frame11.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "Idle-animation-eyes-ultra-1s-frame12",
        "./Sans/costumes/Idle-animation-eyes-ultra-1s-frame12.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "Idle-animation-eyes-ultra-1s-frame13",
        "./Sans/costumes/Idle-animation-eyes-ultra-1s-frame13.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "idle-animation-eyes-true-2s-frame1",
        "./Sans/costumes/idle-animation-eyes-true-2s-frame1.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-true-2s-frame2",
        "./Sans/costumes/idle-animation-eyes-true-2s-frame2.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-2s-frame3",
        "./Sans/costumes/idle-animation-eyes-true-2s-frame3.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-2s-frame4",
        "./Sans/costumes/idle-animation-eyes-true-2s-frame4.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-2s-frame5",
        "./Sans/costumes/idle-animation-eyes-true-2s-frame5.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-true-2s-frame6",
        "./Sans/costumes/idle-animation-eyes-true-2s-frame6.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "idle-animation-eyes-true-2s-frame7",
        "./Sans/costumes/idle-animation-eyes-true-2s-frame7.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-true-2s-frame8",
        "./Sans/costumes/idle-animation-eyes-true-2s-frame8.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-2s-frame9",
        "./Sans/costumes/idle-animation-eyes-true-2s-frame9.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-2s-frame10",
        "./Sans/costumes/idle-animation-eyes-true-2s-frame10.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-2s-frame11",
        "./Sans/costumes/idle-animation-eyes-true-2s-frame11.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "idle-animation-eyes-true-2s-frame12",
        "./Sans/costumes/idle-animation-eyes-true-2s-frame12.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "idle-animation-eyes-true-2s-frame13",
        "./Sans/costumes/idle-animation-eyes-true-2s-frame13.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-2s-frame1",
        "./Sans/costumes/idle-animation-eyes-ultra-2s-frame1.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-2s-frame2",
        "./Sans/costumes/idle-animation-eyes-ultra-2s-frame2.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-2s-frame3",
        "./Sans/costumes/idle-animation-eyes-ultra-2s-frame3.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-2s-frame4",
        "./Sans/costumes/idle-animation-eyes-ultra-2s-frame4.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-2s-frame5",
        "./Sans/costumes/idle-animation-eyes-ultra-2s-frame5.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-2s-frame6",
        "./Sans/costumes/idle-animation-eyes-ultra-2s-frame6.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-2s-frame7",
        "./Sans/costumes/idle-animation-eyes-ultra-2s-frame7.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-2s-frame8",
        "./Sans/costumes/idle-animation-eyes-ultra-2s-frame8.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-2s-frame9",
        "./Sans/costumes/idle-animation-eyes-ultra-2s-frame9.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-2s-frame10",
        "./Sans/costumes/idle-animation-eyes-ultra-2s-frame10.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-2s-frame11",
        "./Sans/costumes/idle-animation-eyes-ultra-2s-frame11.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-2s-frame12",
        "./Sans/costumes/idle-animation-eyes-ultra-2s-frame12.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-ultra-2s-frame13",
        "./Sans/costumes/idle-animation-eyes-ultra-2s-frame13.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "attack-animation-left-frame3",
        "./Sans/costumes/attack-animation-left-frame3.svg",
        { x: 59.588926665613656, y: 77.73026013552712 }
      ),
      new Costume(
        "attack-animation-left-frame2",
        "./Sans/costumes/attack-animation-left-frame2.svg",
        { x: 48.3979238610637, y: 85.58772754296481 }
      ),
      new Costume(
        "attack-animation-left-frame1",
        "./Sans/costumes/attack-animation-left-frame1.svg",
        { x: 51.674476032300845, y: 81.8714930699391 }
      ),
      new Costume(
        "attack-animation-ultra-eyes-ultra-frame1",
        "./Sans/costumes/attack-animation-ultra-eyes-ultra-frame1.svg",
        { x: 59.58892093751365, y: 77.7302615876271 }
      ),
      new Costume(
        "attack-animation-ultra-eyes-ultra-frame2",
        "./Sans/costumes/attack-animation-ultra-eyes-ultra-frame2.svg",
        { x: 48.39792565946368, y: 85.58772749796483 }
      ),
      new Costume(
        "attack-animation-ultra-eyes-ultra-frame3",
        "./Sans/costumes/attack-animation-ultra-eyes-ultra-frame3.svg",
        { x: 51.67447328650087, y: 81.87149526683908 }
      ),
      new Costume(
        "Attack-animation-up-eyes-ultra-frame1",
        "./Sans/costumes/Attack-animation-up-eyes-ultra-frame1.png",
        { x: 111, y: 142 }
      ),
      new Costume(
        "Attack-animation-up-eyes-ultra-frame2",
        "./Sans/costumes/Attack-animation-up-eyes-ultra-frame2.png",
        { x: 109, y: 145 }
      ),
      new Costume(
        "Attack-animation-up-eyes-ultra-frame3",
        "./Sans/costumes/Attack-animation-up-eyes-ultra-frame3.png",
        { x: 109, y: 147 }
      ),
      new Costume(
        "Attack-animation-down-eyes-ultra-frame1",
        "./Sans/costumes/Attack-animation-down-eyes-ultra-frame1.png",
        { x: 112, y: 142 }
      ),
      new Costume(
        "Attack-animation-down-eyes-ultra-frame2",
        "./Sans/costumes/Attack-animation-down-eyes-ultra-frame2.png",
        { x: 109, y: 146 }
      ),
      new Costume(
        "Attack-animation-down-eyes-ultra-frame4",
        "./Sans/costumes/Attack-animation-down-eyes-ultra-frame4.png",
        { x: 111, y: 147 }
      ),
      new Costume(
        "Attack-animation-down-eyes-true-frame1",
        "./Sans/costumes/Attack-animation-down-eyes-true-frame1.png",
        { x: 112, y: 143 }
      ),
      new Costume(
        "Attack-animation-down-eyes-true-frame2",
        "./Sans/costumes/Attack-animation-down-eyes-true-frame2.png",
        { x: 109, y: 147 }
      ),
      new Costume(
        "Attack-animation-down-eyes-true-frame3",
        "./Sans/costumes/Attack-animation-down-eyes-true-frame3.png",
        { x: 111, y: 149 }
      ),
      new Costume(
        "Attack-animation-down-eyes-true-1s-frame1",
        "./Sans/costumes/Attack-animation-down-eyes-true-1s-frame1.png",
        { x: 112, y: 143 }
      ),
      new Costume(
        "Attack-animation-down-eyes-true-frame4",
        "./Sans/costumes/Attack-animation-down-eyes-true-frame4.png",
        { x: 109, y: 149 }
      ),
      new Costume(
        "Attack-animation-down-eyes-true-frame5",
        "./Sans/costumes/Attack-animation-down-eyes-true-frame5.png",
        { x: 111, y: 143 }
      ),
      new Costume(
        "Attack-animation-right-3s-frame1",
        "./Sans/costumes/Attack-animation-right-3s-frame1.png",
        { x: 109, y: 145 }
      ),
      new Costume(
        "Attack-animation-right-3s-frame2",
        "./Sans/costumes/Attack-animation-right-3s-frame2.png",
        { x: 104, y: 149 }
      ),
      new Costume(
        "Attack-animation-right-3s-frame3",
        "./Sans/costumes/Attack-animation-right-3s-frame3.png",
        { x: 102, y: 147 }
      ),
      new Costume(
        "idle-animation-eyes-true-3s-end-frame1idle-animation4",
        "./Sans/costumes/idle-animation-eyes-true-3s-end-frame1idle-animation4.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-true-3s-end-frame2",
        "./Sans/costumes/idle-animation-eyes-true-3s-end-frame2.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-3s-end-frame3",
        "./Sans/costumes/idle-animation-eyes-true-3s-end-frame3.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-3s-end-frame4",
        "./Sans/costumes/idle-animation-eyes-true-3s-end-frame4.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-true-3s-end-frame5",
        "./Sans/costumes/idle-animation-eyes-true-3s-end-frame5.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "idle-animation-eyes-true-3s-end-frame6",
        "./Sans/costumes/idle-animation-eyes-true-3s-end-frame6.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-true-3s-end-frame7",
        "./Sans/costumes/idle-animation-eyes-true-3s-end-frame7.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-true-3s-end-frame8",
        "./Sans/costumes/idle-animation-eyes-true-3s-end-frame8.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-3s-end-frame9",
        "./Sans/costumes/idle-animation-eyes-true-3s-end-frame9.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-3s-end-frame10",
        "./Sans/costumes/idle-animation-eyes-true-3s-end-frame10.png",
        { x: 108, y: 145 }
      ),
      new Costume(
        "idle-animation-eyes-true-3s-end-frame11",
        "./Sans/costumes/idle-animation-eyes-true-3s-end-frame11.png",
        { x: 108, y: 144 }
      ),
      new Costume(
        "idle-animation-eyes-true-3s-end-frame12",
        "./Sans/costumes/idle-animation-eyes-true-3s-end-frame12.png",
        { x: 108, y: 143 }
      ),
      new Costume(
        "idle-animation-eyes-true-3s-end-frame13",
        "./Sans/costumes/idle-animation-eyes-true-3s-end-frame13.png",
        { x: 108, y: 145 }
      ),
      new Costume("Please", "./Sans/costumes/Please.png", { x: 108, y: 144 }),
    ];

    this.sounds = [
      new Sound("Ultra", "./Sans/sounds/Ultra.mp3"),
      new Sound("Music", "./Sans/sounds/Music.mp3"),
    ];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Sans-eyes-false-on-normal-mode" },
        this.whenIReceiveSansEyesFalseOnNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "dialogues-1to4-normal-mode-done" },
        this.whenIReceiveDialogues1to4NormalModeDone
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "bone-floor-complete" },
        this.whenIReceiveBoneFloorComplete
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "bone-tunnel-complete" },
        this.whenIReceiveBoneTunnelComplete
      ),
      new Trigger(Trigger.BROADCAST, { name: "O-x-O-_" }, this.whenIReceiveOXO),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Attack-to-sans" },
        this.whenIReceiveAttackToSans
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game-start" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "sans-turn" },
        this.whenIReceiveSansTurn
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "player-turn" },
        this.whenIReceivePlayerTurn
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-done-normal-mode" },
        this.whenIReceiveBlackoutDoneNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "player-normal-mode-ready" },
        this.whenIReceivePlayerNormalModeReady
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End-game" },
        this.whenIReceiveEndGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete2
      ),
    ];
  }

  *whenIReceiveSansEyesFalseOnNormalMode() {
    this.costume = "idle-animation-eyes-false-frame1";
  }

  *whenIReceiveDialogues1to4NormalModeDone() {
    yield* this.wait(1);
    this.broadcast("Blackout-normal-mode");
  }

  *animation() {
    for (let i = 0; i < this.toNumber(this.stage.vars.animationNumber); i++) {
      yield* this.wait(0.2);
      this.costumeNumber++;
      yield;
    }
  }

  *whenIReceiveBoneFloorComplete() {
    this.costume = "attack-animation-ultra-eyes-ultra-frame1";
    this.broadcast("red-blue-switch");
    this.stage.vars.animationNumber = 2;
    yield* this.animation();
    this.broadcast("bone-tunnel");
    this.stage.vars.dodges = 0;
  }

  *idleAnimation() {
    for (let i = 0; i < 12; i++) {
      yield* this.wait(0.1);
      this.costumeNumber++;
      yield;
    }
  }

  *whenIReceiveBoneTunnelComplete() {
    yield* this.wait(1);
    this.broadcast("O-X-O-X-_");
    this.costume = "idle-animation-eyes-ultra-frame1";
    yield* this.idleAnimation();
  }

  *whenIReceiveOXO() {
    this.costume = "closed eyes";
    this.broadcast("here we go");
    this.broadcast("Dialogues-complete");
    yield* this.wait(1);
    this.broadcast("player-turn");
    this.broadcast("Game-start");
    this.stage.vars.attackNo = 0;
  }

  *whenIReceiveAttackToSans() {
    yield* this.glide(0.5, -93, 93);
    yield* this.wait(0.5);
    yield* this.glide(0.5, 0, 93);
  }

  *whenIReceiveGameStart() {
    yield* this.eyesTrueIdleAnimation();
  }

  *whenIReceiveSansTurn() {
    this.stage.vars.dodges++;
    this.stage.vars.attackNo++;
    this.stage.vars.animationType = 0;
    if (this.toNumber(this.stage.vars.attackNo) === 1) {
      if (this.toNumber(this.stage.vars.slashes) === 1) {
        this.costume = "closed eye-1eye";
        this.broadcast("dialogues-5");
        yield* this.wait(7);
      }
      this.broadcast("Bone-hole");
      this.broadcast("blue-red-switch");
      yield* this.wait(0.5);
      this.broadcast("Attack-2");
      this.stage.vars.movementAllowCheck = "true";
      this.stage.vars.animationType = "STET";
      yield* this.eyesTrueIdleAnimation();
    }
  }

  *whenIReceivePlayerTurn() {
    this.stage.vars.movementAllowCheck = "false";
  }

  *eyesTrueIdleAnimation() {
    while (true) {
      while (!!(this.toString(this.stage.vars.animationType) === "STET")) {
        this.costume = "idle-animation-eyes-true-frame1";
        yield* this.wait(0.1);
        this.costume = "idle-animation-eyes-true-frame2";
        yield* this.wait(0.1);
        this.costume = "idle-animation-eyes-true-frame3";
        yield* this.wait(0.1);
        this.costume = "idle-animation-eyes-true-frame4";
        yield* this.wait(0.1);
        this.costume = "idle-animation-eyes-true-frame5";
        yield* this.wait(0.1);
        this.costume = "idle-animation-eyes-true-frame6";
        yield* this.wait(0.1);
        this.costume = "idle-animation-eyes-true-frame7";
        yield* this.wait(0.1);
        this.costume = "idle-animation-eyes-true-frame8";
        yield* this.wait(0.1);
        this.costume = "idle-animation-eyes-true-frame9";
        yield* this.wait(0.1);
        this.costume = "idle-animation-eyes-true-frame10";
        yield* this.wait(0.1);
        this.costume = "idle-animation-eyes-true-frame11";
        yield* this.wait(0.1);
        this.costume = "idle-animation-eyes-true-frame12";
        yield* this.wait(0.1);
        this.costume = "idle-animation-eyes-true-frame13";
        yield;
      }
      yield;
    }
  }

  *whenIReceiveBlackoutDoneNormalMode() {
    this.visible = true;
    this.costume = "Attack-animation-down-eyes-ultra-frame1";
    this.stage.vars.soulType = "blue";
    this.stage.vars.animationNumber = 2;
    this.stage.vars.movementAllowCheck = "true";
    yield* this.animation();
    this.broadcast("blue-red-switch");
    yield* this.startSound("Ultra");
    this.broadcast("bone-floor");
    this.broadcast("Attack-activated");
  }

  *whenIReceivePlayerNormalModeReady() {
    this.costume = "closed eyes";
    this.visible = true;
    this.effects.ghost = 100;
    for (let i = 0; i < 10; i++) {
      this.effects.ghost -= 10;
      yield;
    }
    this.stage.vars.animationType = 0;
    this.broadcast("dialogues-1to4-normal-mode");
    this.moveAhead();
    this.stage.vars.health = 92;
  }

  *whenIReceiveEndGame() {
    this.stage.vars.animationType = 0;
    this.costume = "closed eye-1eye";
    this.broadcast("dialogues-end-part1");
    yield* this.wait(5);
    this.costume = "Please";
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.stage.vars.soulType = "red";
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }

  *whenIReceiveGameComplete2() {
    this.costume = "closed eyes";
  }
}
