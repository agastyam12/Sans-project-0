/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class BoneViewBlock extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Square", "./BoneViewBlock/costumes/Square.svg", {
        x: 360.40178880127576,
        y: 192.39061255954687,
      }),
      new Costume("rectangle", "./BoneViewBlock/costumes/rectangle.svg", {
        x: 400.71209407974175,
        y: 193.06365477334768,
      }),
    ];

    this.sounds = [new Sound("pop", "./BoneViewBlock/sounds/pop.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game-start-normal-mode" },
        this.whenIReceiveGameStartNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Bone-hole" },
        this.whenIReceiveBoneHole
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Attack-1-normal-mode" },
        this.whenIReceiveAttack1NormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenIReceiveGameStartNormalMode() {
    this.costume = "Square";
    this.moveBehind();
    this.moveAhead(2);
  }

  *whenIReceiveBoneHole() {
    this.costume = "rectangle";
  }

  *whenIReceiveAttack1NormalMode() {
    this.visible = true;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
