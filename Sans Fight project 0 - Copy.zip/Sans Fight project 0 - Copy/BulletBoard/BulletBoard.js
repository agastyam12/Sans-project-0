/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class BulletBoard extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("square ", "./BulletBoard/costumes/square .png", {
        x: 183,
        y: 169,
      }),
      new Costume(
        "square-rectangle frame1",
        "./BulletBoard/costumes/square-rectangle frame1.svg",
        { x: 103.06961273844959, y: 84.5 }
      ),
      new Costume(
        "square-rectangle frame2",
        "./BulletBoard/costumes/square-rectangle frame2.svg",
        { x: 112.85933782313768, y: 84.5 }
      ),
      new Costume(
        "square-rectangle frame3",
        "./BulletBoard/costumes/square-rectangle frame3.svg",
        { x: 116.86096102819164, y: 84.5 }
      ),
      new Costume(
        "square-rectangle frame4",
        "./BulletBoard/costumes/square-rectangle frame4.svg",
        { x: 140.88850659287166, y: 84.5 }
      ),
      new Costume("Rectangle", "./BulletBoard/costumes/Rectangle.svg", {
        x: 152.90309381342462,
        y: 84.5,
      }),
      new Costume(
        "Rectangle-full frame1",
        "./BulletBoard/costumes/Rectangle-full frame1.svg",
        { x: 152.90327117931383, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame2",
        "./BulletBoard/costumes/Rectangle-full frame2.svg",
        { x: 111.96732999999995, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame3",
        "./BulletBoard/costumes/Rectangle-full frame3.svg",
        { x: 111.96791868799994, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame4",
        "./BulletBoard/costumes/Rectangle-full frame4.svg",
        { x: 111.96875926309988, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame5",
        "./BulletBoard/costumes/Rectangle-full frame5.svg",
        { x: 111.96906862309979, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame6",
        "./BulletBoard/costumes/Rectangle-full frame6.svg",
        { x: 111.9686638464998, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame7",
        "./BulletBoard/costumes/Rectangle-full frame7.svg",
        { x: 111.96827119369982, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame8",
        "./BulletBoard/costumes/Rectangle-full frame8.svg",
        { x: 111.96852386719974, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame9",
        "./BulletBoard/costumes/Rectangle-full frame9.svg",
        { x: 111.96836999999996, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame10",
        "./BulletBoard/costumes/Rectangle-full frame10.svg",
        { x: 111.96789227440007, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame11",
        "./BulletBoard/costumes/Rectangle-full frame11.svg",
        { x: 111.96755552140016, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame12",
        "./BulletBoard/costumes/Rectangle-full frame12.svg",
        { x: 111.96721409500012, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame13",
        "./BulletBoard/costumes/Rectangle-full frame13.svg",
        { x: 111.96760106490015, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame14",
        "./BulletBoard/costumes/Rectangle-full frame14.svg",
        { x: 111.96752975799998, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame15",
        "./BulletBoard/costumes/Rectangle-full frame15.svg",
        { x: 111.968325, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame16",
        "./BulletBoard/costumes/Rectangle-full frame16.svg",
        { x: 111.96832147960001, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame17",
        "./BulletBoard/costumes/Rectangle-full frame17.svg",
        { x: 121.91677352329145, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame18",
        "./BulletBoard/costumes/Rectangle-full frame18.svg",
        { x: 131.86520826028297, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame19",
        "./BulletBoard/costumes/Rectangle-full frame19.svg",
        { x: 143.23481621488756, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame20",
        "./BulletBoard/costumes/Rectangle-full frame20.svg",
        { x: 150.3410615695529, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame21",
        "./BulletBoard/costumes/Rectangle-full frame21.svg",
        { x: 165.97381065269664, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame22",
        "./BulletBoard/costumes/Rectangle-full frame22.svg",
        { x: 174.50111552857527, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame23",
        "./BulletBoard/costumes/Rectangle-full frame23.svg",
        { x: 190.13409866441884, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame24",
        "./BulletBoard/costumes/Rectangle-full frame24.svg",
        { x: 202.92491254861744, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame25",
        "./BulletBoard/costumes/Rectangle-full frame25.svg",
        { x: 211.4519733096958, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame26",
        "./BulletBoard/costumes/Rectangle-full frame26.svg",
        { x: 218.55789018026138, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame27",
        "./BulletBoard/costumes/Rectangle-full frame27.svg",
        { x: 231.3485234592788, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame28",
        "./BulletBoard/costumes/Rectangle-full frame28.svg",
        { x: 241.29683178617034, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame29",
        "./BulletBoard/costumes/Rectangle-full frame29.svg",
        { x: 249.82396140774875, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame30",
        "./BulletBoard/costumes/Rectangle-full frame30.svg",
        { x: 261.19348545785357, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame31",
        "./BulletBoard/costumes/Rectangle-full frame31.svg",
        { x: 279.66887596242356, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame32",
        "./BulletBoard/costumes/Rectangle-full frame32.svg",
        { x: 302.4078984146327, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame33",
        "./BulletBoard/costumes/Rectangle-full frame33.svg",
        { x: 322.3045930256153, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full frame34",
        "./BulletBoard/costumes/Rectangle-full frame34.svg",
        { x: 330.831614265694, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full",
        "./BulletBoard/costumes/Rectangle-full.svg",
        { x: 342.2012195081985, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame1",
        "./BulletBoard/costumes/Rectangle-full finish frame1.svg",
        { x: 342.2012195081985, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame2",
        "./BulletBoard/costumes/Rectangle-full finish frame2.svg",
        { x: 342.2009870667985, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame3",
        "./BulletBoard/costumes/Rectangle-full finish frame3.svg",
        { x: 342.2012179819985, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame4",
        "./BulletBoard/costumes/Rectangle-full finish frame4.svg",
        { x: 342.2010590370985, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame5",
        "./BulletBoard/costumes/Rectangle-full finish frame5.svg",
        { x: 342.20089016709846, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame6",
        "./BulletBoard/costumes/Rectangle-full finish frame6.svg",
        { x: 342.2010918865984, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame7",
        "./BulletBoard/costumes/Rectangle-full finish frame7.svg",
        { x: 342.2011641298984, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame8",
        "./BulletBoard/costumes/Rectangle-full finish frame8.svg",
        { x: 342.20100453769845, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame9",
        "./BulletBoard/costumes/Rectangle-full finish frame9.svg",
        { x: 342.20126872129833, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame10",
        "./BulletBoard/costumes/Rectangle-full finish frame10.svg",
        { x: 342.20129197629836, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame11",
        "./BulletBoard/costumes/Rectangle-full finish frame11.svg",
        { x: 342.20156670919835, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame12",
        "./BulletBoard/costumes/Rectangle-full finish frame12.svg",
        { x: 342.2015802271983, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame13",
        "./BulletBoard/costumes/Rectangle-full finish frame13.svg",
        { x: 342.2017469871982, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish frame14",
        "./BulletBoard/costumes/Rectangle-full finish frame14.svg",
        { x: 342.20204880339816, y: 84.5 }
      ),
      new Costume(
        "Rectangle-full finish",
        "./BulletBoard/costumes/Rectangle-full finish.svg",
        { x: 342.2022232485982, y: 84.5 }
      ),
    ];

    this.sounds = [new Sound("pop", "./BulletBoard/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "O-x-O-_" }, this.whenIReceiveOXO),
      new Trigger(
        Trigger.BROADCAST,
        { name: "sans-turn" },
        this.whenIReceiveSansTurn
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Bone-hole" },
        this.whenIReceiveBoneHole
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-done-normal-mode" },
        this.whenIReceiveBlackoutDoneNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenIReceiveOXO() {
    this.visible = false;
  }

  *whenIReceiveSansTurn() {
    this.visible = true;
  }

  *whenIReceiveBoneHole() {
    this.costume = "square ";
    for (let i = 0; i < 5; i++) {
      this.costumeNumber++;
      yield;
    }
    this.stage.vars.borderX = 101;
    this.stage.vars.borderNx = -102;
  }

  *whenIReceiveBlackoutDoneNormalMode() {
    this.costume = "square ";
    this.visible = true;
    this.stage.vars.borderNx = -56;
    this.stage.vars.borderNy = -87;
    this.stage.vars.borderY = 15;
    this.stage.vars.borderX = 55;
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
