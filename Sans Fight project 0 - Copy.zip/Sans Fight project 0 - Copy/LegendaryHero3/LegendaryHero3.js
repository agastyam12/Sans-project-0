/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class LegendaryHero3 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "undertale_text_box (11)",
        "./LegendaryHero3/costumes/undertale_text_box (11).png",
        { x: 4, y: 76 }
      ),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game-start-normal-mode" },
        this.whenIReceiveGameStartNormalMode
      ),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Select-item" },
        this.whenIReceiveSelectItem
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];

    this.vars.lHero3Usable = "true";
  }

  *whenbackdropswitchesto() {
    this.vars.lHero3Usable = "true";
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenIReceiveGameStartNormalMode() {
    this.visible = false;
  }

  *whenKeySpacePressed() {
    if (this.toString(this.vars.lHero3Usable) === "true") {
      if (this.toNumber(this.stage.vars.itemSelect) === 6) {
        this.vars.lHero3Usable = "false";
        this.visible = false;
        this.broadcast("L. Hero eaten");
      }
    }
  }

  *whenIReceiveSelectItem() {
    if (this.toString(this.vars.lHero3Usable) === "true") {
      while (!(this.toString(this.stage.vars.itemStart) === "false")) {
        if (this.compare(this.stage.vars.itemSelect, 5) > 0) {
          this.moveAhead();
          this.visible = true;
          this.goto(0, -37);
        }
        if (this.compare(this.stage.vars.itemSelect, 5) < 0) {
          this.visible = false;
        }
        yield;
      }
    }
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
