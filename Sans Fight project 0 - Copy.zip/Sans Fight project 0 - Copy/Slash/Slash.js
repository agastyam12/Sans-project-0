/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Slash extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "output-onlinegiftools (1)",
        "./Slash/costumes/output-onlinegiftools (1).png",
        { x: 450, y: 360 }
      ),
      new Costume(
        "output-onlinegiftools (1)2",
        "./Slash/costumes/output-onlinegiftools (1)2.png",
        { x: 450, y: 360 }
      ),
      new Costume(
        "output-onlinegiftools (1)3",
        "./Slash/costumes/output-onlinegiftools (1)3.png",
        { x: 450, y: 360 }
      ),
      new Costume(
        "output-onlinegiftools (1)4",
        "./Slash/costumes/output-onlinegiftools (1)4.png",
        { x: 450, y: 360 }
      ),
      new Costume(
        "output-onlinegiftools (1)5",
        "./Slash/costumes/output-onlinegiftools (1)5.png",
        { x: 450, y: 360 }
      ),
      new Costume(
        "output-onlinegiftools (1)6",
        "./Slash/costumes/output-onlinegiftools (1)6.png",
        { x: 450, y: 360 }
      ),
      new Costume(
        "output-onlinegiftools (1)7",
        "./Slash/costumes/output-onlinegiftools (1)7.svg",
        { x: 0, y: 0 }
      ),
    ];

    this.sounds = [new Sound("Slash", "./Slash/sounds/Slash.mp3")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Attack-to-sans" },
        this.whenIReceiveAttackToSans
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "player-normal-mode-ready" },
        this.whenIReceivePlayerNormalModeReady
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenIReceiveAttackToSans() {
    this.stage.vars.slashes++;
    this.moveAhead();
    this.visible = true;
    this.costume = "output-onlinegiftools (1)";
    yield* this.playSoundUntilDone("Slash");
    for (let i = 0; i < 6; i++) {
      yield* this.wait(0.05);
      this.costumeNumber++;
      yield;
    }
    this.visible = false;
  }

  *whenIReceivePlayerNormalModeReady() {
    this.visible = false;
  }

  *whenbackdropswitchesto() {
    this.stage.vars.slashes = 0;
    this.visible = false;
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenbackdropswitchesto3() {
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
