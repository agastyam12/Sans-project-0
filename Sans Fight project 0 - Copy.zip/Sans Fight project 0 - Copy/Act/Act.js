/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Act extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("act", "./Act/costumes/act.png", { x: 131, y: 47 }),
      new Costume("Act-activiated", "./Act/costumes/Act-activiated.svg", {
        x: 66,
        y: 23.5,
      }),
    ];

    this.sounds = [new Sound("select", "./Act/sounds/select.mp3")];

    this.triggers = [
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "player-turn" },
        this.whenIReceivePlayerTurn
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-done-normal-mode" },
        this.whenIReceiveBlackoutDoneNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "player-normal-mode-ready" },
        this.whenIReceivePlayerNormalModeReady
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenKeySpacePressed() {
    if (this.toNumber(this.stage.vars.optionNumber) === 2) {
      yield* this.wait(0.1);
      yield* this.startSound("select");
      this.stage.vars.optionNumber = 100;
      this.stage.vars.actSelect = "1stTRUE";
      this.stage.vars.playerTurn = 0;
      yield* this.wait(0.1);
      this.broadcast("Act-select-character");
    }
  }

  *whenIReceivePlayerTurn() {
    while (!(this.toNumber(this.stage.vars.playerTurn) === 0)) {
      if (this.toNumber(this.stage.vars.optionNumber) === 2) {
        this.visible = true;
        this.costume = "Act-activiated";
      }
      if (!(this.toNumber(this.stage.vars.optionNumber) === 2)) {
        this.visible = true;
        this.costume = "act";
      }
      yield;
    }
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenIReceiveBlackoutDoneNormalMode() {
    this.visible = true;
  }

  *whenIReceivePlayerNormalModeReady() {
    this.costume = "act";
    this.visible = true;
    this.effects.ghost = 100;
    for (let i = 0; i < 10; i++) {
      this.effects.ghost -= 10;
      yield;
    }
    this.moveAhead();
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
