/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class FightBar extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("On", "./FightBar/costumes/On.svg", {
        x: 5.777670280373854,
        y: 54.99999999999997,
      }),
      new Costume("Off", "./FightBar/costumes/Off.svg", {
        x: 5.7776700000000005,
        y: 55,
      }),
    ];

    this.sounds = [new Sound("pop", "./FightBar/sounds/pop.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Fight-selected-interact" },
        this.whenIReceiveFightSelectedInteract
      ),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "sans-turn" },
        this.whenIReceiveSansTurn
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "player-normal-mode-ready" },
        this.whenIReceivePlayerNormalModeReady
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];

    this.vars.fightSelectedStop = "stop";
  }

  *whenIReceiveFightSelectedInteract() {
    yield* this.wait(0.5);
    this.effects.clear();
    this.costume = "On";
    this.goto(230, -39);
    this.vars.fightSelectedStop = "go";
    this.visible = true;
    if (this.toString(this.vars.fightSelectedStop) === "go") {
      while (!(this.toString(this.vars.fightSelectedStop) === "stop")) {
        if (this.x === 230) {
          while (
            !(
              this.x === -230 ||
              this.toString(this.vars.fightSelectedStop) === "stop"
            )
          ) {
            this.x -= 10;
            yield;
          }
        }
        if (this.x === -230) {
          while (
            !(
              this.x === 230 ||
              this.toString(this.vars.fightSelectedStop) === "stop"
            )
          ) {
            this.x += 10;
            yield;
          }
        }
        yield;
      }
    }
  }

  *whenKeySpacePressed() {
    if (this.toString(this.stage.vars.fightSelect) === "true") {
      this.vars.fightSelectedStop = "stop";
      this.stage.vars.fightSelect = "false";
      this.goto(this.x, -37);
      this.effects.ghost = 0;
      this.broadcast("Attack-to-sans");
      for (let i = 0; i < 10; i++) {
        yield* this.wait(0.05);
        this.costume = "Off";
        yield* this.wait(0.05);
        this.effects.ghost += 10;
        this.costume = "On";
        yield;
      }
      this.broadcast("sans-turn");
      this.visible = false;
    }
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenIReceiveSansTurn() {
    this.visible = false;
  }

  *whenIReceivePlayerNormalModeReady() {
    this.visible = false;
  }

  *whenbackdropswitchesto3() {
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
