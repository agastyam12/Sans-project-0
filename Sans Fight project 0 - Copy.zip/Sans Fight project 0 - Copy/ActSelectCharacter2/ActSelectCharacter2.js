/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class ActSelectCharacter2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "undertale_text_box (3)",
        "./ActSelectCharacter2/costumes/undertale_text_box (3).png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "undertale_text_box (2)",
        "./ActSelectCharacter2/costumes/undertale_text_box (2).png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "undertale_text_box (4)",
        "./ActSelectCharacter2/costumes/undertale_text_box (4).png",
        { x: 289, y: 76 }
      ),
      new Costume(
        "undertale_text_box (6)",
        "./ActSelectCharacter2/costumes/undertale_text_box (6).png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)2",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)2.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)4",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)4.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)5",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)5.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)7",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)7.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)6",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)6.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)8",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)8.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)9",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)9.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)10",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)10.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)11",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)11.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)3",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)3.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)14",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)14.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)15",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)15.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)16",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)16.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)17",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)17.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)18",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)18.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)19",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)19.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)20",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)20.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)21",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)21.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)22",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)22.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)23",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)23.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)24",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)24.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)25",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)25.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)12",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)12.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)27",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)27.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)13",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)13.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)29",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)29.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)30",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)30.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)31",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)31.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)32",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)32.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)33",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)33.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)34",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)34.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)35",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)35.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)36",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)36.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)37",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)37.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)38",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)38.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)39",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)39.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)40",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)40.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)41",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)41.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)42",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)42.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)43",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)43.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)44",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)44.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)45",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)45.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)26",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)26.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)47",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)47.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)28",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)28.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)48",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)48.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)49",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)49.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)50",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)50.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)51",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)51.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)52",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)52.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)53",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)53.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)54",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)54.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)55",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)55.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)56",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)56.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)57",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)57.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)58",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)58.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)59",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)59.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)46",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)46.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)62",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)62.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)61",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)61.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)63",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)63.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)64",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)64.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)65",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)65.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)66",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)66.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)67",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)67.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)68",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)68.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)69",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)69.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)70",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)70.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)60",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)60.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)72",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)72.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)73",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)73.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)74",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)74.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)75",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)75.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)76",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)76.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)77",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)77.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)78",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)78.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)79",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)79.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)80",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)80.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)81",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)81.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)82",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)82.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)83",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)83.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)84",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)84.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)85",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)85.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)86",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)86.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)87",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)87.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)88",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)88.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)89",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)89.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)90",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)90.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)91",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)91.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)92",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)92.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)93",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)93.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)94",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)94.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)95",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)95.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)97",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)97.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)98",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)98.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)99",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)99.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)100",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)100.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)101",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)101.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)102",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)102.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)103",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)103.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)104",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)104.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)71",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)71.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)106",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)106.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)107",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)107.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)108",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)108.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)109",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)109.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)110",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)110.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)111",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)111.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)112",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)112.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)113",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)113.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)114",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)114.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)115",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)115.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)105",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)105.png",
        { x: 291, y: 78 }
      ),
      new Costume(
        "undertale_text_box (6)96",
        "./ActSelectCharacter2/costumes/undertale_text_box (6)96.png",
        { x: 291, y: 78 }
      ),
    ];

    this.sounds = [
      new Sound("select", "./ActSelectCharacter2/sounds/select.mp3"),
      new Sound("txt", "./ActSelectCharacter2/sounds/txt.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.KEY_PRESSED, { key: "w" }, this.whenKeyWPressed),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      ),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Act-select-character" },
        this.whenIReceiveActSelectCharacter
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenKeyWPressed() {
    if (this.toString(this.stage.vars.actSelect) === "1stTRUE") {
      this.costume = "undertale_text_box (3)";
      this.stage.vars.actSelect = "2ndTRUE";
    }
  }

  *whenKeySpacePressed() {
    if (this.toString(this.stage.vars.actSelect) === "2ndTRUE") {
      yield* this.wait(0.1);
      yield* this.startSound("select");
      this.stage.vars.actSelect = "3rdTRUE";
      this.costume = "undertale_text_box (4)";
    }
  }

  *whenKeySpacePressed2() {
    if (this.toString(this.stage.vars.actSelect) === "3rdTRUE") {
      yield* this.wait(0.1);
      yield* this.startSound("select");
      this.stage.vars.actSelect = 0;
      yield* this.dialougeRun();
      yield* this.wait(3);
      this.broadcast("sans-turn");
      this.visible = false;
    }
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *dialougeRun() {
    this.costume = "undertale_text_box (6)";
    for (let i = 0; i < 115; i++) {
      this.costumeNumber++;
      yield;
    }
  }

  *whenIReceiveActSelectCharacter() {
    this.visible = true;
    this.costume = "undertale_text_box (2)";
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
