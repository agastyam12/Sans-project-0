/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class GasterBlaster2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "output-onlinegiftools",
        "./GasterBlaster2/costumes/output-onlinegiftools.png",
        { x: 320, y: 240 }
      ),
      new Costume(
        "output-onlinegiftools2",
        "./GasterBlaster2/costumes/output-onlinegiftools2.png",
        { x: 320, y: 240 }
      ),
      new Costume(
        "output-onlinegiftools3",
        "./GasterBlaster2/costumes/output-onlinegiftools3.png",
        { x: 320, y: 240 }
      ),
      new Costume(
        "output-onlinegiftools4",
        "./GasterBlaster2/costumes/output-onlinegiftools4.png",
        { x: 320, y: 240 }
      ),
      new Costume(
        "output-onlinegiftools5",
        "./GasterBlaster2/costumes/output-onlinegiftools5.png",
        { x: 320, y: 240 }
      ),
      new Costume(
        "output-onlinegiftools6",
        "./GasterBlaster2/costumes/output-onlinegiftools6.png",
        { x: 320, y: 240 }
      ),
      new Costume(
        "output-onlinegiftools7",
        "./GasterBlaster2/costumes/output-onlinegiftools7.png",
        { x: 320, y: 240 }
      ),
      new Costume(
        "output-onlinegiftools8",
        "./GasterBlaster2/costumes/output-onlinegiftools8.png",
        { x: 320, y: 240 }
      ),
      new Costume(
        "output-onlinegiftools9",
        "./GasterBlaster2/costumes/output-onlinegiftools9.svg",
        { x: 24.5, y: 28 }
      ),
      new Costume(
        "output-onlinegiftools10",
        "./GasterBlaster2/costumes/output-onlinegiftools10.svg",
        { x: 24.5, y: 41.5 }
      ),
      new Costume(
        "output-onlinegiftools11",
        "./GasterBlaster2/costumes/output-onlinegiftools11.svg",
        { x: 24.5, y: 71.5 }
      ),
      new Costume(
        "output-onlinegiftools12",
        "./GasterBlaster2/costumes/output-onlinegiftools12.svg",
        { x: 24.5, y: 100 }
      ),
      new Costume(
        "output-onlinegiftools13",
        "./GasterBlaster2/costumes/output-onlinegiftools13.png",
        { x: 320, y: 240 }
      ),
      new Costume(
        "output-onlinegiftools14",
        "./GasterBlaster2/costumes/output-onlinegiftools14.png",
        { x: 320, y: 240 }
      ),
      new Costume(
        "output-onlinegiftools15",
        "./GasterBlaster2/costumes/output-onlinegiftools15.png",
        { x: 320, y: 240 }
      ),
    ];

    this.sounds = [
      new Sound("charge", "./GasterBlaster2/sounds/charge.mp3"),
      new Sound("Shoot", "./GasterBlaster2/sounds/Shoot.mp3"),
    ];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "O-X-O-X-_" },
        this.whenIReceiveOXOX
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "player-normal-mode-ready" },
        this.whenIReceivePlayerNormalModeReady
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenIReceiveOXOX() {
    this.moveAhead();
    this.size = 175;
    this.goto(55, -160);
    this.direction = -90;
    this.visible = true;
    yield* this.spawn();
    this.goto(-120, -140);
    this.direction = -45;
    yield* this.spawn();
    this.goto(55, -160);
    this.direction = -90;
    yield* this.spawn();
    this.goto(-145, -20);
    this.direction = 0;
    this.size = 250;
    yield* this.spawn();
  }

  *whenIReceivePlayerNormalModeReady() {
    this.moveAhead();
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *spawn() {
    yield* this.startSound("charge");
    this.costume = "output-onlinegiftools";
    for (let i = 0; i < 7; i++) {
      this.costumeNumber++;
      yield;
    }
    yield* this.wait(0.5);
    yield* this.startSound("Shoot");
    for (let i = 0; i < 7; i++) {
      yield* this.wait(0.01);
      this.costumeNumber++;
      yield;
    }
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenbackdropswitchesto3() {
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
