window.onload = function () {
  const start_music = document.getElementById("background_music_menu");
  const body = document.getElementById("body");
  const start_button = document.getElementById("button_normal");
  const audio_start = document.getElementById("start_animation");
  const next = document.getElementById("next-button");
  const carousel_item1 = document.getElementById("carousel-item1");
  const carousel_item2 = document.getElementById("carousel-item2");
  const carousel_item3 = document.getElementById("carousel-item3");
  const carousel = document.getElementById("carousel-container");
  let carousel_counter = 0;

  if (!start_music || !audio_start || !carousel_item3) {
    console.error("One or more required elements are missing in the DOM.");
    return;
  }

  carousel.classList.add("hidden");
  carousel_item2.classList.add("hidden");
  carousel_item3.classList.add("hidden");

  function background_music() {
    try {
      start_music.play();
      start_music.volume = 0.06;
      start_music.loop = true;
    } catch (error) {
      console.warn(
        "Background music autoplay was blocked by the browser:",
        error
      );
    }
  }
  background_music();

  start_button.addEventListener("click", () => {
    body.classList.add("fade-out");
    try {
      audio_start.play();
    } catch (error) {
      console.warn("Audio playback was blocked by the browser:", error);
    }
    setTimeout(() => {
      body.classList.remove("fade-out");
      body.classList.add("fade-in");
      const menu = document.getElementById("menu-id");
      if (menu) menu.remove();
      carousel.classList.remove("hidden");
    }, 1000);
  });

  next.addEventListener("click", () => {
    try {
      audio_start.play();
    } catch (error) {
      console.warn("Audio playback was blocked by the browser:", error);
    }

    if (carousel_counter === 0) {
      carousel_item1.classList.add("fade-out");
      setTimeout(() => {
        carousel_item1.remove();
        carousel_item2.classList.remove("hidden");
        carousel_item2.classList.add("fade-in");
        setTimeout(() => {
          carousel_item2.classList.remove("fade-in");
        }, 1000);
      }, 1000);
      carousel_counter = 1;
    } else if (carousel_counter === 1) {
      carousel_item2.classList.add("fade-out");
      setTimeout(() => {
        carousel_item3.classList.add("fade-in");
        carousel_item3.classList.remove("hidden");
        carousel_item2.remove();
        setTimeout(() => {
          carousel_item3.classList.remove("fade-in");
          next.classList.add("fade-out");
        }, 1000);
        next.remove();
      }, 1000);
      carousel_counter = 2;
    }
  });

  const start_normal_mode = document.getElementById("start-button");

  start_normal_mode.addEventListener("click", () => {
    try {
      audio_start.play();
    } catch (error) {
      console.warn("Audio playback was blocked by the browser:", error);
    }

    const fadeOutInterval = setInterval(() => {
      if (start_music.volume > 0.01) {
        start_music.volume -= 0.01;
      } else {
        start_music.volume = 0;
        start_music.pause();
        clearInterval(fadeOutInterval);
      }
    }, 450);

    setTimeout(() => {
      carousel_item3.classList.add("fade-out");
    }, 2000);

    setTimeout(() => {
      window.location.href = "index.html";
    }, 3000);
  });
};
