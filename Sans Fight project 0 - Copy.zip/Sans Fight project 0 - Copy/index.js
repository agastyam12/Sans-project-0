import {
  Project,
  Sprite,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Sans from "./Sans/Sans.js";
import Player from "./Player/Player.js";
import BoneViewBlock from "./BoneViewBlock/BoneViewBlock.js";
import BulletBoard from "./BulletBoard/BulletBoard.js";
import HpBarDetails from "./HpBarDetails/HpBarDetails.js";
import HpBarRed from "./HpBarRed/HpBarRed.js";
import HpBarYellow from "./HpBarYellow/HpBarYellow.js";
import Fight from "./Fight/Fight.js";
import Act from "./Act/Act.js";
import Item from "./Item/Item.js";
import Mercy from "./Mercy/Mercy.js";
import Danger from "./Danger/Danger.js";
import GasterBlaster from "./GasterBlaster/GasterBlaster.js";
import GasterBlaster2 from "./GasterBlaster2/GasterBlaster2.js";
import GasterBlaster3 from "./GasterBlaster3/GasterBlaster3.js";
import GasterBlaster4 from "./GasterBlaster4/GasterBlaster4.js";
import GasterBlaster5 from "./GasterBlaster5/GasterBlaster5.js";
import GasterBlaster6 from "./GasterBlaster6/GasterBlaster6.js";
import WhiteBoneAttack1 from "./WhiteBoneAttack1/WhiteBoneAttack1.js";
import WhiteBoneAttack2 from "./WhiteBoneAttack2/WhiteBoneAttack2.js";
import Dialogues from "./Dialogues/Dialogues.js";
import ReapersEye from "./ReapersEye/ReapersEye.js";
import FightBar from "./FightBar/FightBar.js";
import Slash from "./Slash/Slash.js";
import WhiteBoneAttack3 from "./WhiteBoneAttack3/WhiteBoneAttack3.js";
import WhiteBoneAttack4 from "./WhiteBoneAttack4/WhiteBoneAttack4.js";
import WhiteBoneAttack7 from "./WhiteBoneAttack7/WhiteBoneAttack7.js";
import WhiteBoneAttack8 from "./WhiteBoneAttack8/WhiteBoneAttack8.js";
import WhiteBoneAttack9 from "./WhiteBoneAttack9/WhiteBoneAttack9.js";
import WhiteBoneAttack10 from "./WhiteBoneAttack10/WhiteBoneAttack10.js";
import FightSelectCharacter from "./FightSelectCharacter/FightSelectCharacter.js";
import ActSelectCharacter2 from "./ActSelectCharacter2/ActSelectCharacter2.js";
import MerySelected from "./MerySelected/MerySelected.js";
import ItemBoard from "./ItemBoard/ItemBoard.js";
import Pie from "./Pie/Pie.js";
import Steak from "./Steak/Steak.js";
import INoodles from "./INoodles/INoodles.js";
import LegendaryHero from "./LegendaryHero/LegendaryHero.js";
import LegendaryHero2 from "./LegendaryHero2/LegendaryHero2.js";
import LegendaryHero3 from "./LegendaryHero3/LegendaryHero3.js";
import LegendaryHero4 from "./LegendaryHero4/LegendaryHero4.js";
import LegendaryHero5 from "./LegendaryHero5/LegendaryHero5.js";
import StartButton from "./StartButton/StartButton.js";

const stage = new Stage({ costumeNumber: 3 });

const sprites = {
  Sans: new Sans({
    x: 0,
    y: 93,
    direction: 0,
    rotationStyle: Sprite.RotationStyle.LEFT_RIGHT,
    costumeNumber: 14,
    size: 75,
    visible: false,
    layerOrder: 30,
  }),
  Player: new Player({
    x: 4.199999999999989,
    y: -86.99999999999933,
    direction: 0,
    rotationStyle: Sprite.RotationStyle.DONT_ROTATE,
    costumeNumber: 2,
    size: 13,
    visible: false,
    layerOrder: 7,
  }),
  BoneViewBlock: new BoneViewBlock({
    x: 40,
    y: 32,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 100,
    visible: false,
    layerOrder: 10,
  }),
  BulletBoard: new BulletBoard({
    x: 0,
    y: -36,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 6,
    size: 75,
    visible: false,
    layerOrder: 11,
  }),
  HpBarDetails: new HpBarDetails({
    x: -101,
    y: -118,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 35,
    visible: false,
    layerOrder: 31,
  }),
  HpBarRed: new HpBarRed({
    x: 13,
    y: -118,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 50,
    visible: false,
    layerOrder: 35,
  }),
  HpBarYellow: new HpBarYellow({
    x: 12,
    y: -118,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 50,
    visible: false,
    layerOrder: 38,
  }),
  Fight: new Fight({
    x: -150,
    y: -150,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 67,
    visible: false,
    layerOrder: 33,
  }),
  Act: new Act({
    x: -45,
    y: -151,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 70,
    visible: false,
    layerOrder: 32,
  }),
  Item: new Item({
    x: 113,
    y: -133,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 70,
    visible: false,
    layerOrder: 34,
  }),
  Mercy: new Mercy({
    x: 210,
    y: -92,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 70,
    visible: false,
    layerOrder: 36,
  }),
  Danger: new Danger({
    x: 0,
    y: -80,
    direction: 180,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 110.00000000000001,
    visible: false,
    layerOrder: 27,
  }),
  GasterBlaster: new GasterBlaster({
    x: 145,
    y: -40,
    direction: 180,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 15,
    size: 225,
    visible: false,
    layerOrder: 39,
  }),
  GasterBlaster2: new GasterBlaster2({
    x: -145,
    y: -20,
    direction: 0,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 15,
    size: 225,
    visible: false,
    layerOrder: 40,
  }),
  GasterBlaster3: new GasterBlaster3({
    x: -55,
    y: 100,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 15,
    size: 175,
    visible: false,
    layerOrder: 42,
  }),
  GasterBlaster4: new GasterBlaster4({
    x: -150,
    y: 15,
    direction: 0,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 15,
    size: 175,
    visible: false,
    layerOrder: 41,
  }),
  GasterBlaster5: new GasterBlaster5({
    x: -48.47702382770893,
    y: 38.137269680327094,
    direction: 180,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 9,
    size: 100,
    visible: false,
    layerOrder: 29,
  }),
  GasterBlaster6: new GasterBlaster6({
    x: 57.064896132074864,
    y: 41.50520806132503,
    direction: 180,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 15,
    size: 100,
    visible: false,
    layerOrder: 28,
  }),
  WhiteBoneAttack1: new WhiteBoneAttack1({
    x: -190,
    y: 100,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 3,
    size: 50,
    visible: false,
    layerOrder: 9,
  }),
  WhiteBoneAttack2: new WhiteBoneAttack2({
    x: 120,
    y: -45,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 3,
    size: 50,
    visible: false,
    layerOrder: 8,
  }),
  Dialogues: new Dialogues({
    x: 0,
    y: -38,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 37,
  }),
  ReapersEye: new ReapersEye({
    x: 0,
    y: -38,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 155,
    visible: false,
    layerOrder: 12,
  }),
  FightBar: new FightBar({
    x: -10,
    y: -37,
    direction: -90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 13,
  }),
  Slash: new Slash({
    x: 11,
    y: 52,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 7,
    size: 50,
    visible: false,
    layerOrder: 43,
  }),
  WhiteBoneAttack3: new WhiteBoneAttack3({
    x: -120,
    y: -45,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 50,
    visible: false,
    layerOrder: 6,
  }),
  WhiteBoneAttack4: new WhiteBoneAttack4({
    x: -120,
    y: -45,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 50,
    visible: false,
    layerOrder: 5,
  }),
  WhiteBoneAttack7: new WhiteBoneAttack7({
    x: 120,
    y: 30,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 50,
    visible: false,
    layerOrder: 2,
  }),
  WhiteBoneAttack8: new WhiteBoneAttack8({
    x: 120,
    y: 30,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 50,
    visible: false,
    layerOrder: 4,
  }),
  WhiteBoneAttack9: new WhiteBoneAttack9({
    x: -120,
    y: 30,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 50,
    visible: false,
    layerOrder: 1,
  }),
  WhiteBoneAttack10: new WhiteBoneAttack10({
    x: -120,
    y: 30,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 50,
    visible: false,
    layerOrder: 3,
  }),
  FightSelectCharacter: new FightSelectCharacter({
    x: -4,
    y: -36,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 110.00000000000001,
    visible: false,
    layerOrder: 14,
  }),
  ActSelectCharacter2: new ActSelectCharacter2({
    x: 5.892975402715351,
    y: -30.090623508698712,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 110.00000000000001,
    visible: false,
    layerOrder: 15,
  }),
  MerySelected: new MerySelected({
    x: 0,
    y: -26,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 102,
    size: 100,
    visible: false,
    layerOrder: 16,
  }),
  ItemBoard: new ItemBoard({
    x: 0,
    y: -37,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 19,
  }),
  Pie: new Pie({
    x: 0,
    y: -37,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 23,
  }),
  Steak: new Steak({
    x: 0,
    y: -50,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 22,
  }),
  INoodles: new INoodles({
    x: 0,
    y: -37,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 21,
  }),
  LegendaryHero: new LegendaryHero({
    x: 0,
    y: -50,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 24,
  }),
  LegendaryHero2: new LegendaryHero2({
    x: 0,
    y: -37,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 20,
  }),
  LegendaryHero3: new LegendaryHero3({
    x: 0,
    y: -37,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 17,
  }),
  LegendaryHero4: new LegendaryHero4({
    x: -133,
    y: -51,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 25,
  }),
  LegendaryHero5: new LegendaryHero5({
    x: 22.726225141990653,
    y: -67.8273710585326,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 18,
  }),
  StartButton: new StartButton({
    x: 0,
    y: -10,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 26,
  }),
};

const project = new Project(stage, sprites, {
  frameRate: 30,
});
export default project;
