/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class ReapersEye extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Reapers-eye", "./ReapersEye/costumes/Reapers-eye.svg", {
        x: 154.5126316945292,
        y: 38.25645687840566,
      }),
    ];

    this.sounds = [new Sound("pop", "./ReapersEye/sounds/pop.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Fight selected" },
        this.whenIReceiveFightSelected
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Attack-to-sans" },
        this.whenIReceiveAttackToSans
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "player-normal-mode-ready" },
        this.whenIReceivePlayerNormalModeReady
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "sans-turn" },
        this.whenIReceiveSansTurn
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenIReceiveFightSelected() {
    if (this.toString(this.stage.vars.fightSelect) === "3rdTRUE") {
      this.visible = true;
      this.stage.vars.fightSelect = "true";
      this.effects.clear();
      this.effects.ghost = 100;
      for (let i = 0; i < 5; i++) {
        this.effects.ghost -= 20;
        yield;
      }
      yield* this.wait(0.5);
      this.broadcast("Fight-selected-interact");
    }
  }

  *whenIReceiveAttackToSans() {
    yield* this.wait(1);
    for (let i = 0; i < 5; i++) {
      this.effects.ghost += 20;
      yield;
    }
  }

  *whenIReceivePlayerNormalModeReady() {
    this.visible = false;
  }

  *whenIReceiveSansTurn() {
    this.visible = false;
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
