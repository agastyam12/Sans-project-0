/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class HpBarYellow extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./HpBarYellow/costumes/costume1.png", {
        x: 85,
        y: 36,
      }),
    ];

    this.sounds = [
      new Sound("pop", "./HpBarYellow/sounds/pop.wav"),
      new Sound("Music", "./HpBarYellow/sounds/Music.mp3"),
    ];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game-start" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-done-normal-mode" },
        this.whenIReceiveBlackoutDoneNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "player-normal-mode-ready" },
        this.whenIReceivePlayerNormalModeReady
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenIReceiveGameStart() {
    this.stage.vars.music = "play";
    if (this.toString(this.stage.vars.music) === "play") {
      while (!!(this.toString(this.stage.vars.music) === "play")) {
        yield* this.playSoundUntilDone("Music");
        yield;
      }
    }
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenIReceiveBlackoutDoneNormalMode() {
    this.visible = true;
  }

  *whenIReceivePlayerNormalModeReady() {
    yield* this.wait(0.5);
    this.visible = true;
    this.effects.ghost = 100;
    for (let i = 0; i < 10; i++) {
      this.effects.ghost -= 10;
      yield;
    }
    this.moveAhead(1);
    this.moveAhead();
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
