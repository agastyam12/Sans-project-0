/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Fight extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("fight-activiated", "./Fight/costumes/fight-activiated.png", {
        x: 134,
        y: 47,
      }),
      new Costume("fight", "./Fight/costumes/fight.png", { x: 136, y: 45 }),
    ];

    this.sounds = [new Sound("select", "./Fight/sounds/select.mp3")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "player-turn" },
        this.whenIReceivePlayerTurn
      ),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "sans-turn" },
        this.whenIReceiveSansTurn
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-done-normal-mode" },
        this.whenIReceiveBlackoutDoneNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "player-normal-mode-ready" },
        this.whenIReceivePlayerNormalModeReady
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Blackout-normal-mode" },
        this.whenIReceiveBlackoutNormalMode
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game complete" },
        this.whenIReceiveGameComplete
      ),
    ];
  }

  *whenIReceivePlayerTurn() {
    while (!(this.toNumber(this.stage.vars.playerTurn) === 0)) {
      if (this.toNumber(this.stage.vars.optionNumber) === 1) {
        this.visible = true;
        this.costume = "fight-activiated";
      }
      if (!(this.toNumber(this.stage.vars.optionNumber) === 1)) {
        this.visible = true;
        this.costume = "fight";
      }
      yield;
    }
  }

  *whenKeySpacePressed() {
    if (this.toNumber(this.stage.vars.optionNumber) === 1) {
      yield* this.wait(0.1);
      yield* this.startSound("select");
      this.stage.vars.optionNumber = 100;
      this.stage.vars.fightSelect = "1stTRUE";
      this.stage.vars.playerTurn = 0;
      yield* this.wait(0.1);
      this.broadcast("Fight-select-character");
    }
  }

  *whenIReceiveSansTurn() {
    this.costume = "fight";
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }

  *whenIReceiveBlackoutDoneNormalMode() {
    this.visible = true;
  }

  *whenIReceivePlayerNormalModeReady() {
    this.visible = true;
    this.costume = "fight";
    this.effects.ghost = 100;
    for (let i = 0; i < 10; i++) {
      this.effects.ghost -= 10;
      yield;
    }
    this.moveAhead();
  }

  *whenbackdropswitchesto2() {
    this.visible = false;
  }

  *whenIReceiveBlackoutNormalMode() {
    this.visible = false;
  }

  *whenIReceiveGameComplete() {
    this.visible = true;
    this.effects.clear();
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.effects.clear();
    this.visible = false;
  }
}
